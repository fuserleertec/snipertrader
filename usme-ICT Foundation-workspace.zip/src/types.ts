export interface ConfluenceInputs {
  sessionTime: "london" | "ny_open" | "off_hours";
  weeklyBias: "bullish" | "bearish" | "mixed";
  dailyBias: "bullish" | "bearish" | "mixed";
  fvgObDetails: string;
  chochBosDetails: string;
  smtDetails: string;
  volumeDetails: string;
  closedCandle: boolean;
  userNotes: string;
}

export interface FactorScore {
  name: string;
  score: number; // out of 20
  details: string;
}

export interface GeminiAnalysisResponse {
  analysis: string;
  filterKillzone: {
    pass: boolean;
    details: string;
  };
  filterHTFBias: {
    pass: boolean;
    details: string;
    direction: "LONG ONLY" | "SHORT ONLY" | "NO TRADE";
  };
  filterSmartMoneyScore: {
    score: number;
    tier: "ELITE" | "PRIME" | "STANDARD";
    pass: boolean;
    factors: FactorScore[];
  };
  filterClosedCandle: {
    pass: boolean;
    details: string;
  };
  overallPass: boolean;
  executionPlan: {
    riskPercentage: number;
    entryAdvice: string;
    stopLossAdvice: string;
    targetsAdvice: string;
  };
  propChallengeContext: string;
}

export interface TradeSimulation {
  id: string;
  tradeNumber: number;
  setupName: string;
  tier: "ELITE" | "PRIME" | "STANDARD";
  riskPercentage: number;
  direction: "LONG" | "SHORT";
  outcome: "WIN_T1" | "WIN_T2" | "WIN_T3" | "LOSS";
  pnlAmount: number;
  pnlPercentage: number;
  endingBalance: number;
  peakEquity: number;
  trailingDrawdown: number; // current drawdown from peak equity
  notes: string;
}

export interface SimulatorState {
  accountSize: number;
  balance: number;
  peakEquity: number;
  maxTrailingDrawdown: number; // peak trailing drawdown reached
  consecutiveLosses: number;
  dailyLossTotal: number;
  weeklyLossTotal: number;
  tradeHistory: TradeSimulation[];
  isPassed: boolean;
  isFailed: boolean;
  failureReason: string;
  isPausedFor30m: boolean; // 30-min pause after 3 losses
}
