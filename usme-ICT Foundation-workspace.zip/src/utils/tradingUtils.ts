import { ConfluenceInputs, TradeSimulation, SimulatorState } from "../types";

export function calculatePositionSize(
  balance: number,
  riskPercent: number,
  stopDistance: number, // in points or price difference
  assetType: "forex" | "crypto_stock_indices",
  pipPointValue: number = 10 // default $10 per lot/standard contract
): {
  riskAmount: number;
  positionSize: number;
  stopDistance: number;
} {
  const riskAmount = balance * (riskPercent / 100);
  
  if (stopDistance <= 0) {
    return { riskAmount, positionSize: 0, stopDistance: 0 };
  }

  let positionSize = 0;
  if (assetType === "forex") {
    // Forex standard calculation: Lot Size = Risk Amount / (Stop Loss Pips * Pip Value per Lot)
    // where pipPointValue represents the dollar value of 1 pip for 1 standard lot (e.g., $10 for EURUSD)
    positionSize = riskAmount / (stopDistance * pipPointValue);
  } else {
    // Shares / Crypto / Indices direct price calculation: Shares = Risk Amount / Price Distance
    positionSize = riskAmount / stopDistance;
  }

  return {
    riskAmount,
    positionSize: parseFloat(positionSize.toFixed(4)),
    stopDistance
  };
}

// Generate a random market setup that is presented to the user in the Prop Challenge Simulator
export function generateRandomSetup(idCounter: number): {
  id: string;
  asset: string;
  sessionTime: "london" | "ny_open" | "off_hours";
  weeklyBias: "bullish" | "bearish" | "mixed";
  dailyBias: "bullish" | "bearish" | "mixed";
  closedCandle: boolean;
  fvgObDetails: string;
  chochBosDetails: string;
  smtDetails: string;
  volumeDetails: string;
  calculatedScore: number;
  tier: "ELITE" | "PRIME" | "STANDARD";
  description: string;
  stopDistance: number;
  entryPrice: number;
} {
  const assets = ["EURUSD", "GBPUSD", "NAS100", "US30", "XAUUSD (Gold)"];
  const asset = assets[Math.floor(Math.random() * assets.length)];
  
  // High probability of being in active sessions
  const sessions: ("london" | "ny_open" | "off_hours")[] = ["london", "ny_open", "london", "ny_open", "off_hours"];
  const sessionTime = sessions[Math.floor(Math.random() * sessions.length)];
  
  // Biases
  const biasOptions: ("bullish" | "bearish" | "mixed")[] = ["bullish", "bearish", "mixed"];
  // Weight it so they align 60% of the time
  const weeklyBias = biasOptions[Math.floor(Math.random() * biasOptions.length)];
  let dailyBias = weeklyBias;
  if (Math.random() > 0.6) {
    dailyBias = biasOptions[Math.floor(Math.random() * biasOptions.length)];
  }

  const closedCandle = Math.random() > 0.15; // 85% chance of being closed

  // Let's randomize confluence factors
  const hasFvg = Math.random() > 0.2;
  const hasChoch = Math.random() > 0.25;
  const hasSmt = Math.random() > 0.35;
  const hasVol = Math.random() > 0.3;

  // Let's compute score manually
  let score = 0;
  // FVG/OB alignment (up to 20%)
  const fvgScore = hasFvg ? (Math.random() > 0.5 ? 20 : 15) : 0;
  // CHoCH/BOS (up to 20%)
  const chochScore = hasChoch ? (Math.random() > 0.5 ? 20 : 15) : 0;
  // SMT Divergence (up to 20%)
  const smtScore = hasSmt ? (Math.random() > 0.5 ? 20 : 15) : 0;
  // Volume (up to 20%)
  const volScore = hasVol ? (Math.random() > 0.5 ? 20 : 15) : 0;
  // HTF Bias alignment (up to 20%)
  const biasScore = (weeklyBias === dailyBias && weeklyBias !== "mixed") ? 20 : (weeklyBias !== "mixed" && dailyBias !== "mixed" ? 10 : 0);

  score = fvgScore + chochScore + smtScore + volScore + biasScore;

  let tier: "ELITE" | "PRIME" | "STANDARD" = "STANDARD";
  if (score >= 90) {
    tier = "ELITE";
  } else if (score >= 80) {
    tier = "PRIME";
  }

  // Generate technical descriptions
  const fvgObDetails = hasFvg 
    ? "Clean 15m Fair Value Gap aligns perfectly with the 4H Order Block." 
    : "No visible Fair Value Gap, price is trading in thin liquidity.";
  
  const chochBosDetails = hasChoch 
    ? "5m Break of Structure occurred with aggressive institutional displacement." 
    : "Price is grinding, no clean change of character observed.";
    
  const smtDetails = hasSmt 
    ? "Strong SMT Divergence observed at the swing low with correlated asset." 
    : "No clear SMT Divergence present.";
    
  const volumeDetails = hasVol 
    ? "Volume is 1.8x the 10-period average on the breakout candle." 
    : "Average volume, no distinctive buying/selling surge.";

  let description = "";
  if (tier === "ELITE") {
    description = `Premium A+ setup on ${asset} during ${sessionTime === "london" ? "London" : "NY Open"} Session. High-volume displacement with clear SMT.`;
  } else if (tier === "PRIME") {
    description = `Strong Prime-tier setup on ${asset}. HTF Biases align, with minor FVG alignment.`;
  } else {
    description = `Standard-tier or sub-par setup on ${asset}. ${score < 80 ? "DO NOT TRADE — fails minimum 80% Smart Money Score threshold." : "Meets baseline standard but lacks premium confluence."}`;
  }

  // Base parameters
  let entryPrice = 0;
  let stopDistance = 0;

  if (asset.includes("EURUSD") || asset.includes("GBPUSD")) {
    entryPrice = asset.includes("EURUSD") ? 1.08500 : 1.26500;
    stopDistance = parseFloat((12 + Math.random() * 15).toFixed(1)); // 12 to 27 pips
  } else if (asset.includes("NAS100") || asset.includes("US30")) {
    entryPrice = asset.includes("NAS100") ? 18200 : 39100;
    stopDistance = Math.floor(45 + Math.random() * 80); // 45 to 125 points
  } else {
    entryPrice = 2320; // Gold
    stopDistance = parseFloat((4 + Math.random() * 8).toFixed(1)); // 4 to 12 dollars
  }

  return {
    id: `setup_${idCounter}`,
    asset,
    sessionTime,
    weeklyBias,
    dailyBias,
    closedCandle,
    fvgObDetails,
    chochBosDetails,
    smtDetails,
    volumeDetails,
    calculatedScore: score,
    tier,
    description,
    stopDistance,
    entryPrice
  };
}

// Simulates the outcome of a trade based on the rules
export function simulateTradeOutcome(
  setup: ReturnType<typeof generateRandomSetup>,
  accountBalance: number,
  customWinRate: number = 50
): {
  outcome: "WIN_T1" | "WIN_T2" | "WIN_T3" | "LOSS";
  pnlPercentage: number;
  pnlAmount: number;
  notes: string;
} {
  const isWin = Math.random() * 100 < customWinRate;
  
  let riskPercent = 0.2; // default STANDARD
  if (setup.tier === "ELITE") riskPercent = 0.5;
  else if (setup.tier === "PRIME") riskPercent = 0.35;

  if (!isWin) {
    const lossPercentage = -riskPercent;
    const lossAmount = accountBalance * (lossPercentage / 100);
    return {
      outcome: "LOSS",
      pnlPercentage: lossPercentage,
      pnlAmount: lossAmount,
      notes: `Trade hit initial Stop Loss at 1.5x ATR. Full loss of ${riskPercent}% risk limit.`
    };
  }

  // For wins, let's distribute outcome among Target 1, 2, and 3
  // USME rule: 
  // T1 (1.5x Risk) -> SL moved to breakeven
  // T2 (3x Risk) -> Close 50% (+1.5x Risk locked), activate trailing stop
  // T3 (5x Risk) -> Trail remaining remainder, full profit potential of 5x risk on remaining 50%
  
  const roll = Math.random();
  if (roll < 0.2) {
    // Target 1 hit, then stopped at breakeven
    // P&L is 0 (since SL was moved to breakeven at 1.5x, but no partials taken in the script, wait!
    // In script: "T1 at 1.5x Risk -> move stop loss to breakeven, trade is protected."
    // "T2 at 3x Risk -> close 50% of position. Let remaining half run with a trailing stop active."
    // So if it hits T1 and stops out at breakeven, net gain is 0% (excluding commissions/spreads).
    return {
      outcome: "WIN_T1",
      pnlPercentage: 0,
      pnlAmount: 0,
      notes: "Price hit Target 1 (1.5x Risk). Stop loss moved to breakeven. Price then reversed, stopping the trade at $0 net loss."
    };
  } else if (roll < 0.65) {
    // Target 2 hit: 50% of position closed at 3.0x risk = 1.5x risk gained.
    // The remaining 50% gets stopped out at breakeven (or trailed slightly, let's say stopped out at breakeven)
    // Net gain = 50% of size * 3.0x risk = 1.5 * riskPercent.
    const winPercentage = 1.5 * riskPercent;
    const winAmount = accountBalance * (winPercentage / 100);
    return {
      outcome: "WIN_T2",
      pnlPercentage: winPercentage,
      pnlAmount: winAmount,
      notes: `Hit Target 2 (3.0x Risk). Closed 50% for standard profit. Trailing stop hit on remainder. Total gain: +${winPercentage.toFixed(3)}% (+1.5R).`
    };
  } else {
    // Target 3 hit! 
    // 50% of position closed at 3.0x risk = 1.5x risk gained.
    // 50% of position closed at 5.0x risk = 2.5x risk gained.
    // Total gain = 1.5 + 2.5 = 4.0x riskPercent.
    const winPercentage = 4.0 * riskPercent;
    const winAmount = accountBalance * (winPercentage / 100);
    return {
      outcome: "WIN_T3",
      pnlPercentage: winPercentage,
      pnlAmount: winAmount,
      notes: `ELITE RUN! Price hit Target 3 (5.0x Risk). Closed all partials. Total gain: +${winPercentage.toFixed(3)}% (+4.0R).`
    };
  }
}
