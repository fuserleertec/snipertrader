export interface ScriptSection {
  id: string;
  title: string;
  timeRange: string;
  voiceover: string;
  keyTakeaways: string[];
  tips: string;
  technicalConcept: string;
}

export const tutorialScript: ScriptSection[] = [
  {
    id: "intro",
    title: "Intro: Mechanical Prop Firm Blueprint",
    timeRange: "0:00–0:30",
    voiceover: "Welcome. In this tutorial, I'm going to walk you through the SniperTrader USME ICT Foundation Masterplan — a strict mechanical trading system designed to help you pass prop firm funded account challenges. By the end of this video, you'll know exactly what to look for, when to enter a trade, how to size your position, and how to manage it from entry to exit. Let's get into it.",
    keyTakeaways: [
      "Designed specifically for passing Prop Firm Funded Account Challenges.",
      "Uses a strict mechanical system, leaving no room for human emotional errors.",
      "Covers the complete sequence from setup filters, execution protocol, to risk preservation."
    ],
    tips: "Prop firms do not fail you because your strategy is bad; they fail you because you violate daily drawdown or weekly allocation limits. USME eliminates this.",
    technicalConcept: "Prop challenges reward high-efficiency systems with extremely low risk-to-reward standard variances."
  },
  {
    id: "section1",
    title: "Section 1: The Core Concept",
    timeRange: "0:30–1:30",
    voiceover: "The USME Masterplan is built on one core principle: we don't predict — we react to confirmed institutional footprint. That means no guessing, no gut feelings. Every single trade must pass a 4-step mechanical filter before you even think about entering. If any step fails, you skip the trade. No exceptions.",
    keyTakeaways: [
      "We do not forecast high timeframe markets; we react when institutional players leave traces.",
      "No gut feelings or discretionary trades. If a rule isn't checked, the trade does not exist.",
      "The 4-step filter is a gateway that guards your capital from low-probability transactions."
    ],
    tips: "Successful trading is 90% waiting and 10% execution. If there is no institutional trace, sit on your hands.",
    technicalConcept: "Institutional footprint is characterized by heavy order displacement, creating visible Fair Value Gaps (FVGs) and Order Blocks (OBs)."
  },
  {
    id: "section2",
    title: "Section 2: The 4-Step Setup Filter",
    timeRange: "1:30–4:00",
    voiceover: "Let's break down the four filters.\n\nFilter 1 — Killzone Confirmation.\nYou only trade during two sessions: London, from 2:00 to 5:00 AM Eastern, and the New York Open, from 8:30 to 11:00 AM Eastern. These are the windows where institutional players are most active. If price is moving outside these windows, you ignore it completely. Off-hours signals are automatically discarded.\n\nFilter 2 — HTF Bias Alignment.\nBefore any trade, check your higher timeframe bias. Your Weekly and Daily charts must agree. If both are bullish, you only take longs. If both are bearish, you only take shorts. If they conflict — mixed signals — there is no trade. Simple.\n\nFilter 3 — Smart Money Score of 80% or Higher.\nThe Smart Money Score is a confluence meter that evaluates five factors: Fair Value Gap and Order Block alignment, Change of Character and Break of Structure, SMT Divergence, Volume Confirmation, and Higher Timeframe Alignment. A score of 90% or above is ELITE tier. 80–89% is PRIME tier. You need at least 80% to proceed. Anything below that is not a trade.\n\nFilter 4 — The Closed Candle Rule.\nNever enter on a candle that's still forming. Wait for the signal bar to fully close. Then enter on the open of the next candle. This one rule alone eliminates a huge number of false entries.",
    keyTakeaways: [
      "Filter 1: London (2:00–5:00 AM EST) and NY Open (8:30–11:00 AM EST) only.",
      "Filter 2: Weekly and Daily charts MUST agree on the bias. Bullish+Bullish = Longs, Bearish+Bearish = Shorts, mixed = No Trade.",
      "Filter 3: Confluence score evaluated across 5 core indicators. Minimum 80% is required.",
      "Filter 4: Absolute wait for candle closure. Never trade on open, unformed candles."
    ],
    tips: "The closed candle rule is your shield against 'Fakeouts'. A displacement is only real if the candle body closes outside the zone.",
    technicalConcept: "SMT Divergence (Smart Money Technique) identifies structural differences between correlated assets (like EURUSD and GBPUSD, or S&P500 and Nasdaq) to confirm institutional accumulation/distribution."
  },
  {
    id: "section3",
    title: "Section 3: The 6-Step Execution Protocol",
    timeRange: "4:00–7:00",
    voiceover: "Once a trade passes all four filters, you move into execution. Here's the protocol, step by step.\n\nStep 1 — Entry.\nPlace a limit order at the Fair Value Gap or Order Block level. Enter on the open of the next candle after your signal bar closes.\n\nStep 2 — Stop Loss.\nSet your initial stop loss at 1.5 times the 14-period ATR. For longs, that's below your entry. For shorts, above it. This gives the trade room to breathe while keeping you protected.\n\nStep 3 — Position Size.\nThis is determined by your SOTD tier. ELITE signals get 0.5% account risk. PRIME signals get 0.35%. STANDARD signals get 0.2%. On a $100,000 account, that's $500, $350, or $200 at risk per trade.\n\nStep 4 — Target 1 at 1.5x Risk.\nWhen price hits 1.5 times your initial risk, move your stop loss to breakeven. The trade is now protected. You cannot lose money on it from this point forward.\n\nStep 5 — Target 2 at 3x Risk.\nWhen price hits 3 times your risk, close 50% of the position. Bank that profit. Let the remaining half continue running with a trailing stop active.\n\nStep 6 — Target 3 at 5x Risk.\nThe final target is 5 times your risk. From T2 onward, manage the remainder with a 1.5x ATR trailing stop. You let the winner run until that trailing stop is hit.",
    keyTakeaways: [
      "Step 1 (Entry): Limit order at FVG or OB open immediately on next candle open.",
      "Step 2 (Stop Loss): Strict 1.5x of the 14-period ATR (Average True Range).",
      "Step 3 (Position Sizing): Elite (0.5% risk), Prime (0.35% risk), Standard (0.2% risk).",
      "Step 4 (Target 1 - 1.5R): Price reaches 1.5x Risk -> Instantly move SL to Breakeven (0 risk).",
      "Step 5 (Target 2 - 3.0R): Close 50% of the position, bank profits, activate trailing stop.",
      "Step 6 (Target 3 - 5.0R): Maximum targets, trailing remainder with 1.5x ATR stop."
    ],
    tips: "Moving to breakeven at 1.5R is a game-changer for psychological comfort. It ensures you have high survival rates in prop challenges.",
    technicalConcept: "Average True Range (ATR) represents the average volatility of the market over 14 candles, providing a natural volatility buffer for stops."
  },
  {
    id: "section4",
    title: "Section 4: Prop Challenge Risk Management",
    timeRange: "7:00–9:00",
    voiceover: "The USME Masterplan is built specifically for prop firm challenges. Here's how the risk structure works.\n\nYour goal is to reach a 10% profit — so $110,000 on a $100k account — while never letting drawdown exceed 8% from your peak equity.\n\nThere are six risk pillars to follow:\n\nOne — max 0.5% risk per trade, adjusted by tier.\nTwo — if you lose 1.5% in a single day, stop trading for the rest of that day.\nThree — if you lose 3% in a week, step away until Monday.\nFour — always track drawdown from your highest equity point, not your starting balance.\nFive — only take trades where you can realistically target a 1:3 risk-to-reward ratio. If a 1:3 isn't achievable on the setup, skip it.\nSix — after three consecutive losses, pause for 30 minutes. Step back, review your setups, and reset mentally before continuing.",
    keyTakeaways: [
      "Prop firm limits: 10% profit target, 8% peak trailing drawdown ceiling.",
      "Pillar 1: Max 0.5% risk (ELITE tier), scaled down for lower tiers.",
      "Pillar 2: 1.5% Daily Drawdown Lock (Stop trading immediately if hit).",
      "Pillar 3: 3.0% Weekly Drawdown Lock (Step away until Monday).",
      "Pillar 4: Trailing drawdown measured from peak equity, not starting balance.",
      "Pillar 5: Strict 1:3 minimum risk-to-reward ratio (Skip if unachievable).",
      "Pillar 6: Reset Rule (3 consecutive losses = mandatory 30-min break)."
    ],
    tips: "Trailing Drawdown is the prop firm's secret weapon to catch greedy traders. If you are up $2,000, your drawdown limit also moves up by $2,000.",
    technicalConcept: "Peak Trailing Drawdown matches your absolute high equity mark, creating a sliding ceiling for allowed loss."
  },
  {
    id: "section5",
    title: "Section 5: Path to Funded (The Mathematics)",
    timeRange: "9:00–10:00",
    voiceover: "With a 50% win rate and a 1:3 risk-to-reward ratio, the math works in your favor. ELITE signals produce 1.5% gain per win. PRIME signals produce 1.05%. STANDARD signals produce 0.6%. Based on a realistic mix of all three tiers, you're looking at approximately 25 to 35 winning trades to pass the challenge. This is a marathon, not a sprint.",
    keyTakeaways: [
      "A 50% win rate with an average 1:3 risk-to-reward is mathematically guaranteed to pass challenges.",
      "Elite returns 1.5% on wins (3x 0.5%). Prime returns 1.05%. Standard returns 0.6%.",
      "Expect about 25 to 35 well-filtered winning trades to secure full funding."
    ],
    tips: "Do not rush. If you take 2 high-quality setups a week, you can pass a $100k challenge easily within 2 to 3 months with zero risk of blowing the account.",
    technicalConcept: "Positive mathematical expectancy is calculated as: Expectancy = (Win% * AvgWin) - (Loss% * AvgLoss). For USME, this is extremely high."
  },
  {
    id: "section6",
    title: "Section 6: The Mindset",
    timeRange: "10:00–11:00",
    voiceover: "Before we close out, the most important section. The funded trader mindset. The market does not care about your P&L. It cares about your process.\n\nAt the end of every trading day, ask yourself four questions:\nDid I follow the 4-step setup filter?\nDid I respect my position sizing by SOTD tier?\nDid I manage the trade according to the protocol?\nWhat can I improve tomorrow?\n\nIf the answer to the first three is yes, you are doing this correctly — regardless of whether that day was green or red. Consistency beats aggression every time.",
    keyTakeaways: [
      "The market does not care about your P&L. It only cares about your process.",
      "Three crucial daily self-review questions for continuous mental calibration.",
      "A red day where you followed all USME rules is a SUCCESSFUL day. A green day where you broke rules is a FAILURE."
    ],
    tips: "Write these four questions on a sticky note and place it below your monitor. They are your psychological anchor.",
    technicalConcept: "Process-driven trading reduces cortisol and prevents the amygdala hijack that leads to revenge trading."
  },
  {
    id: "outro",
    title: "Outro: Mechanical Success",
    timeRange: "11:00–11:30",
    voiceover: "That's the full USMEICT Foundation Masterplan. Four filters before you enter. Six steps to execute and manage. Six risk pillars to protect the account. Follow the process mechanically, and the results will follow. Trade responsibly — past performance does not guarantee future results. Good luck.",
    keyTakeaways: [
      "4 Entry Filters + 6 Execution Steps + 6 Risk Pillars = Funded Success.",
      "Practice on demo accounts first before entering live funded evaluations.",
      "The path is open to those who submit fully to mechanical discipline."
    ],
    tips: "The sniper waits for the target. Your target is the USME institutional footprint. Happy trading!",
    technicalConcept: "Mechanical trading removes cognitive load, turning retail market analysis into an assembly-line operation."
  }
];
