import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialization function for Gemini
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY environment variable is required but missing. Please set it in the Settings > Secrets panel.");
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// REST API endpoint for AI Smart Money Setup Analysis
app.post("/api/gemini/analyze", async (req, res) => {
  try {
    const { 
      sessionTime, 
      weeklyBias, 
      dailyBias, 
      fvgObDetails, 
      chochBosDetails, 
      smtDetails, 
      volumeDetails, 
      closedCandle,
      userNotes,
      fvgObStatus,
      chochBosStatus,
      smtStatus,
      volumeStatus,
      htfStatus
    } = req.body;

    const ai = getGeminiClient();

    const prompt = `
      You are the Elite SniperTrader USME (United Smart Money Engine) Institutional Assistant.
      Evaluate the following raw trading setup inputs strictly against the USME ICT Foundation Masterplan rules.
      
      USER INPUT DETAILS:
      - Killzone/Time: ${sessionTime || "Not Specified"}
      - Weekly Bias: ${weeklyBias || "Not Specified"}
      - Daily Bias: ${dailyBias || "Not Specified"}
      - Is Candle Closed?: ${closedCandle ? "Yes" : "No"}
      - User Raw Context & Notes: "${userNotes || "No extra context provided."}"

      USER SELECTED FACTOR STATUSES (Use these direct status selections for scoring confluences):
      1. Fair Value Gap & Order Block Alignment: ${fvgObStatus || "Not Specified"} (Status selection: ${fvgObStatus || "yes"}) - Notes: ${fvgObDetails || "None"}
      2. Change of Character / Break of Structure: ${chochBosStatus || "Not Specified"} (Status selection: ${chochBosStatus || "yes"}) - Notes: ${chochBosDetails || "None"}
      3. SMT Divergence Alignment: ${smtStatus || "Not Specified"} (Status selection: ${smtStatus || "yes"}) - Notes: ${smtDetails || "None"}
      4. Volume Confirmation: ${volumeStatus || "Not Specified"} (Status selection: ${volumeStatus || "yes"}) - Notes: ${volumeDetails || "None"}
      5. Higher Timeframe Alignment: ${htfStatus || "Not Specified"} (Status selection: ${htfStatus || "yes"})

      USME MASTERPLAN CORE RULES FOR EVALUATION:
      1. Killzone Filter: Trade ONLY London (2:00-5:00 AM Eastern) and NY Open (8:30-11:00 AM Eastern).
      2. HTF Bias Filter: Weekly and Daily charts MUST agree (Bullish+Bullish = Longs only, Bearish+Bearish = Shorts only, Mixed/Conflict = NO TRADE).
      3. Smart Money Score: Score out of 100 based on the 5 factors above (Yes/Full = 20 points, Partial = 10 points, No/None = 0 points):
         - Fair Value Gap & Order Block Alignment (max 20)
         - Change of Character & Break of Structure (max 20)
         - SMT Divergence (max 20)
         - Volume Confirmation (max 20)
         - Higher Timeframe Bias Alignment (max 20)
         * If total score >= 90% -> ELITE tier (0.5% risk).
         * If total score 80-89% -> PRIME tier (0.35% risk).
         * If total score < 80% -> STANDARD tier (0.2% risk or DO NOT TRADE). Under USME, a setup MUST have >= 80% to proceed.
      4. Closed Candle Rule: Wait for signal bar to fully close. Never enter on forming candle.

      Analyze this setup. Be strict, objective, and mechanical. Respect the User Selected Factor Statuses for the final confluences scorecard representation in your JSON. Determine whether each filter passes, assign the correct SOTD Tier, and output a structured plan.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            analysis: {
              type: Type.STRING,
              description: "Overall objective assessment of the institutional footprints. Summarize what is happening."
            },
            filterKillzone: {
              type: Type.OBJECT,
              properties: {
                pass: { type: Type.BOOLEAN, description: "True if sessionTime fits London (2:00-5:00 AM EST) or NY Open (8:30-11:00 AM EST)." },
                details: { type: Type.STRING, description: "Mechanical reasoning about session suitability." }
              },
              required: ["pass", "details"]
            },
            filterHTFBias: {
              type: Type.OBJECT,
              properties: {
                pass: { type: Type.BOOLEAN, description: "True if Weekly and Daily bias agree (e.g., both Bullish or both Bearish)." },
                details: { type: Type.STRING, description: "Mechanical reasoning. If bullish/bearish mixed, explain why it fails." },
                direction: { type: Type.STRING, description: "Allowed direction: 'LONG ONLY', 'SHORT ONLY', or 'NO TRADE'." }
              },
              required: ["pass", "details", "direction"]
            },
            filterSmartMoneyScore: {
              type: Type.OBJECT,
              properties: {
                score: { type: Type.INTEGER, description: "Total score summed up out of 100." },
                tier: { type: Type.STRING, description: "'ELITE' (>=90), 'PRIME' (80-89), or 'STANDARD' (<80)." },
                pass: { type: Type.BOOLEAN, description: "True if score >= 80." },
                factors: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING, description: "e.g. 'FVG & OB Alignment'" },
                      score: { type: Type.INTEGER, description: "Score out of 20." },
                      details: { type: Type.STRING, description: "Reasoning for this factor score." }
                    },
                    required: ["name", "score", "details"]
                  }
                }
              },
              required: ["score", "tier", "pass", "factors"]
            },
            filterClosedCandle: {
              type: Type.OBJECT,
              properties: {
                pass: { type: Type.BOOLEAN, description: "True if Closed Candle is Yes." },
                details: { type: Type.STRING, description: "Commentary on waiting for closed candles." }
              },
              required: ["pass", "details"]
            },
            overallPass: {
              type: Type.BOOLEAN,
              description: "True if ALL 4 filters pass (Killzone, Bias, Score >= 80, Candle Closed)."
            },
            executionPlan: {
              type: Type.OBJECT,
              properties: {
                riskPercentage: { type: Type.NUMBER, description: "0.5 for ELITE, 0.35 for PRIME, 0.2 for STANDARD." },
                entryAdvice: { type: Type.STRING, description: "Entry guidance (limit order at FVG/OB open after close)." },
                stopLossAdvice: { type: Type.STRING, description: "Set stop loss at 1.5x 14-period ATR from entry." },
                targetsAdvice: { type: Type.STRING, description: "Target 1 (1.5x risk) -> Breakeven, Target 2 (3x risk) -> Close 50%, Target 3 (5x risk) -> Trail remainder." }
              },
              required: ["riskPercentage", "entryAdvice", "stopLossAdvice", "targetsAdvice"]
            },
            propChallengeContext: {
              type: Type.STRING,
              description: "Strategic advice matching the 1.5% daily drawdown, 3% weekly drawdown, and 8% peak trailing drawdown rules."
            }
          },
          required: [
            "analysis", 
            "filterKillzone", 
            "filterHTFBias", 
            "filterSmartMoneyScore", 
            "filterClosedCandle", 
            "overallPass", 
            "executionPlan", 
            "propChallengeContext"
          ]
        }
      }
    });

    const data = JSON.parse(response.text || "{}");
    res.json(data);
  } catch (error: any) {
    console.error("Gemini analysis error:", error);
    res.status(500).json({ 
      error: error.message || "An unexpected error occurred during analysis.",
      isMissingKey: !process.env.GEMINI_API_KEY
    });
  }
});

// Serve static assets / Vite Dev server
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`USME ICT Server running on port ${PORT} (NODE_ENV: ${process.env.NODE_ENV || "development"})`);
  });
}

startServer();
