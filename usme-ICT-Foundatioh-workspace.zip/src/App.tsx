import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  BookOpen, 
  Calculator, 
  TrendingUp, 
  Activity, 
  Award, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  ChevronRight, 
  RotateCcw, 
  Sparkles, 
  DollarSign, 
  Clock, 
  ShieldCheck, 
  HelpCircle,
  Play,
  Briefcase,
  LineChart,
  Target,
  ArrowRight,
  Flame,
  Volume2,
  BookMarked,
  Trash2,
  Plus,
  Edit3,
  Save,
  Download,
  Upload,
  Calendar,
  Search,
  Check
} from "lucide-react";
import { ConfluenceInputs, GeminiAnalysisResponse, TradeSimulation, SimulatorState, JournalEntry } from "./types";
import { tutorialScript, ScriptSection } from "./data/tutorialScript";
import { calculatePositionSize, generateRandomSetup, simulateTradeOutcome } from "./utils/tradingUtils";

export default function App() {
  // Tabs State
  const [activeTab, setActiveTab] = useState<"lessons" | "analyzer" | "sizer" | "simulator" | "journal">("lessons");

  // --- TAB 1: LESSONS STATE ---
  const [activeLessonIdx, setActiveLessonIdx] = useState(0);
  const currentLesson = tutorialScript[activeLessonIdx];

  // --- TAB 2: ANALYZER STATE ---
  const [analyzerInputs, setAnalyzerInputs] = useState<ConfluenceInputs>({
    sessionTime: "ny_open",
    weeklyBias: "bullish",
    dailyBias: "bullish",
    fvgObDetails: "Clear 15m Fair Value Gap aligning with the 1H bullish Order Block.",
    chochBosDetails: "5m Break of Structure confirmed with a displacement candle.",
    smtDetails: "SMT Divergence with correlated asset at previous day's low.",
    volumeDetails: "High-volume breakout, 1.5x average on closed signal candle.",
    closedCandle: true,
    userNotes: "Looking to buy the FVG retest on EURUSD. Market swept London session lows before displacement."
  });

  // Interactive Smart Money Score calculator factor states
  const [fvgObStatus, setFvgObStatus] = useState<"yes" | "partial" | "no">("yes");
  const [chochBosStatus, setChochBosStatus] = useState<"yes" | "partial" | "no">("yes");
  const [smtStatus, setSmtStatus] = useState<"yes" | "partial" | "no">("yes");
  const [volumeStatus, setVolumeStatus] = useState<"yes" | "partial" | "no">("yes");
  const [htfStatus, setHtfStatus] = useState<"yes" | "partial" | "no">("yes");

  // Synchronize Weekly/Daily Bias with HTF Status
  useEffect(() => {
    if (analyzerInputs.weeklyBias === analyzerInputs.dailyBias && analyzerInputs.weeklyBias !== "mixed") {
      setHtfStatus("yes");
    } else if (analyzerInputs.weeklyBias !== "mixed" && analyzerInputs.dailyBias !== "mixed" && analyzerInputs.weeklyBias !== analyzerInputs.dailyBias) {
      setHtfStatus("no");
    } else {
      setHtfStatus("partial");
    }
  }, [analyzerInputs.weeklyBias, analyzerInputs.dailyBias]);

  const handleHtfStatusChange = (status: "yes" | "partial" | "no") => {
    setHtfStatus(status);
    if (status === "yes") {
      const targetBias = analyzerInputs.dailyBias === "bearish" ? "bearish" : "bullish";
      setAnalyzerInputs(p => ({ ...p, weeklyBias: targetBias, dailyBias: targetBias }));
    } else if (status === "no") {
      setAnalyzerInputs(p => ({ ...p, weeklyBias: "bullish", dailyBias: "bearish" }));
    } else {
      setAnalyzerInputs(p => ({ ...p, weeklyBias: "bullish", dailyBias: "mixed" }));
    }
  };

  // Calculate live local score using interactive factor statuses
  const getLiveScore = () => {
    let score = 0;
    
    if (fvgObStatus === "yes") score += 20;
    else if (fvgObStatus === "partial") score += 10;

    if (chochBosStatus === "yes") score += 20;
    else if (chochBosStatus === "partial") score += 10;

    if (smtStatus === "yes") score += 20;
    else if (smtStatus === "partial") score += 10;

    if (volumeStatus === "yes") score += 20;
    else if (volumeStatus === "partial") score += 10;

    if (htfStatus === "yes") score += 20;
    else if (htfStatus === "partial") score += 10;

    return score;
  };

  const localScore = getLiveScore();
  const localTier = localScore >= 90 ? "ELITE" : localScore >= 80 ? "PRIME" : "STANDARD";
  
  const isKillzoneActive = analyzerInputs.sessionTime !== "off_hours";
  const isBiasAligned = analyzerInputs.weeklyBias === analyzerInputs.dailyBias && analyzerInputs.weeklyBias !== "mixed";
  const isScoreAcceptable = localScore >= 80;
  const isCandleClosed = analyzerInputs.closedCandle;
  const canLocalTrade = isKillzoneActive && isBiasAligned && isScoreAcceptable && isCandleClosed;

  // AI analysis state
  const [aiResponse, setAiResponse] = useState<GeminiAnalysisResponse | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [loadingStep, setLoadingStep] = useState(0);

  const loadingPhrases = [
    "Opening connection with institutional server...",
    "Scanning market footprints for liquidity pools...",
    "Calculating Fair Value Gap & Order Block alignment...",
    "Auditing SMT Divergence across correlated pairs...",
    "Enforcing Daily & Weekly prop firm risk metrics...",
    "Compiling final mechanical USME score card..."
  ];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isAiLoading) {
      interval = setInterval(() => {
        setLoadingStep((prev) => (prev + 1) % loadingPhrases.length);
      }, 2200);
    }
    return () => clearInterval(interval);
  }, [isAiLoading]);

  const handleAiAnalysis = async () => {
    setIsAiLoading(true);
    setAiError(null);
    setAiResponse(null);
    setLoadingStep(0);

    try {
      const response = await fetch("/api/gemini/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...analyzerInputs,
          fvgObStatus,
          chochBosStatus,
          smtStatus,
          volumeStatus,
          htfStatus
        })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to analyze setup. Please try again.");
      }

      const data = await response.json();
      setAiResponse(data);
    } catch (err: any) {
      console.error(err);
      setAiError(err.message || "An unexpected network error occurred.");
    } finally {
      setIsAiLoading(false);
    }
  };


  // --- TAB 3: POSITION SIZER STATE ---
  const [sizerAccountBalance, setSizerAccountBalance] = useState<number>(100000);
  const [sizerTier, setSizerTier] = useState<"ELITE" | "PRIME" | "STANDARD">("ELITE");
  const [sizerAssetType, setSizerAssetType] = useState<"forex" | "crypto_stock_indices">("forex");
  const [sizerEntryPrice, setSizerEntryPrice] = useState<number>(1.0850);
  const [sizerStopLossDist, setSizerStopLossDist] = useState<number>(15); // pips or points
  const [sizerPipVal, setSizerPipVal] = useState<number>(10); // forex only, standard lot pip value

  const getSizerRiskPercent = () => {
    if (sizerTier === "ELITE") return 0.5;
    if (sizerTier === "PRIME") return 0.35;
    return 0.2;
  };

  const sizerRiskPercent = getSizerRiskPercent();
  const sizerResult = calculatePositionSize(
    sizerAccountBalance,
    sizerRiskPercent,
    sizerStopLossDist,
    sizerAssetType,
    sizerPipVal
  );

  // Profit target calculations
  const stopPrice = sizerAssetType === "crypto_stock_indices"
    ? sizerEntryPrice - sizerStopLossDist // assuming long for sizer visual
    : sizerEntryPrice - (sizerStopLossDist * 0.0001); // forex pip distance

  const target1Price = sizerAssetType === "crypto_stock_indices"
    ? sizerEntryPrice + (sizerStopLossDist * 1.5)
    : sizerEntryPrice + (sizerStopLossDist * 1.5 * 0.0001);

  const target2Price = sizerAssetType === "crypto_stock_indices"
    ? sizerEntryPrice + (sizerStopLossDist * 3.0)
    : sizerEntryPrice + (sizerStopLossDist * 3.0 * 0.0001);

  const target3Price = sizerAssetType === "crypto_stock_indices"
    ? sizerEntryPrice + (sizerStopLossDist * 5.0)
    : sizerEntryPrice + (sizerStopLossDist * 5.0 * 0.0001);


  // --- TAB 4: SIMULATOR STATE ---
  const initialBalance = 100000;
  const [simState, setSimState] = useState<SimulatorState>({
    accountSize: initialBalance,
    balance: initialBalance,
    peakEquity: initialBalance,
    maxTrailingDrawdown: 0,
    consecutiveLosses: 0,
    dailyLossTotal: 0,
    weeklyLossTotal: 0,
    tradeHistory: [],
    isPassed: false,
    isFailed: false,
    failureReason: "",
    isPausedFor30m: false
  });

  const [simWinRate, setSimWinRate] = useState<number>(55);
  const [currentSetup, setCurrentSetup] = useState<ReturnType<typeof generateRandomSetup> | null>(null);
  const [showCertificate, setShowCertificate] = useState(false);

  // --- TAB 5: JOURNAL STATE ---
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(() => {
    const saved = localStorage.getItem("usme_trade_journal");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Failed to parse journal", e);
      }
    }
    return [
      {
        id: "demo-1",
        date: new Date(Date.now() - 24 * 60 * 60 * 1000 * 3).toISOString().slice(0, 10),
        asset: "EURUSD",
        direction: "LONG",
        entryPrice: 1.08250,
        exitPrice: 1.08700,
        stopLoss: 1.08100,
        takeProfit: 1.08700,
        killzone: true,
        htfBias: true,
        smartMoneyScore: 85,
        closedCandle: true,
        protocols: {
          limitEntry: true,
          atrStopLoss: true,
          sotdRisk: true,
          protectedTarget: true,
          takePartials: true,
          trailingStop: false
        },
        adheredToMasterplan: "fully",
        notes: "Clean London Session liquidity sweep of previous day's low, followed by clear 5m displacement and a well-defined Fair Value Gap. Entered on retest of the FVG.",
        postTradeAnalysis: "Executed beautifully. Position sizing was perfect under PRIME rules (0.35% risk). Profit hit Target 3 at 3.0R. Followed all protocols flawlessly.",
        pnlAmount: 1050,
        pnlPercentage: 1.05,
        isWin: true
      },
      {
        id: "demo-2",
        date: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().slice(0, 10),
        asset: "GBPUSD",
        direction: "SHORT",
        entryPrice: 1.26500,
        exitPrice: 1.26800,
        stopLoss: 1.26650,
        takeProfit: 1.26000,
        killzone: true,
        htfBias: false,
        smartMoneyScore: 65,
        closedCandle: true,
        protocols: {
          limitEntry: true,
          atrStopLoss: false,
          sotdRisk: true,
          protectedTarget: false,
          takePartials: false,
          trailingStop: false
        },
        adheredToMasterplan: "no",
        notes: "Tried to force a short at the NY Open despite conflicting weekly/daily biases. SMT divergence was present but minor. Entered too early before proper displacement.",
        postTradeAnalysis: "Violated Risk Pillar 1 and Gateway filter 2 (Weekly and Daily bias must align). I let FOMO dictate this trade because GBPUSD had moved significantly. Stop loss was set too tight (15 pips instead of 1.5x ATR). Immediate area of improvement is to force patience until both biases align.",
        pnlAmount: -350,
        pnlPercentage: -0.35,
        isWin: false
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem("usme_trade_journal", JSON.stringify(journalEntries));
  }, [journalEntries]);

  // Filters state
  const [journalSearch, setJournalSearch] = useState("");
  const [journalFilterAdherence, setJournalFilterAdherence] = useState<"all" | "fully" | "partially" | "no">("all");
  const [journalFilterOutcome, setJournalFilterOutcome] = useState<"all" | "win" | "loss">("all");

  // Form toggle
  const [isAddingEntry, setIsAddingEntry] = useState(false);
  const [editingEntryId, setEditingEntryId] = useState<string | null>(null);

  // Form fields state
  const [formDate, setFormDate] = useState("");
  const [formAsset, setFormAsset] = useState("EURUSD");
  const [formDirection, setFormDirection] = useState<"LONG" | "SHORT">("LONG");
  const [formEntryPrice, setFormEntryPrice] = useState("");
  const [formExitPrice, setFormExitPrice] = useState("");
  const [formStopLoss, setFormStopLoss] = useState("");
  const [formTakeProfit, setFormTakeProfit] = useState("");
  
  // Filters
  const [formKillzone, setFormKillzone] = useState(true);
  const [formHtfBias, setFormHtfBias] = useState(true);
  const [formScore, setFormScore] = useState<number>(80);
  const [formClosedCandle, setFormClosedCandle] = useState(true);

  // Protocols
  const [formProtoLimitEntry, setFormProtoLimitEntry] = useState(true);
  const [formProtoAtrStopLoss, setFormProtoAtrStopLoss] = useState(true);
  const [formProtoSotdRisk, setFormProtoSotdRisk] = useState(true);
  const [formProtoProtectedTarget, setFormProtoProtectedTarget] = useState(true);
  const [formProtoTakePartials, setFormProtoTakePartials] = useState(true);
  const [formProtoTrailingStop, setFormProtoTrailingStop] = useState(false);

  // Adherence and notes
  const [formAdherence, setFormAdherence] = useState<"fully" | "partially" | "no">("fully");
  const [formNotes, setFormNotes] = useState("");
  const [formPostAnalysis, setFormPostAnalysis] = useState("");
  const [formCustomPnlAmount, setFormCustomPnlAmount] = useState("");
  const [formCustomPnlPercentage, setFormCustomPnlPercentage] = useState("");
  const [formAutoCalculatePnl, setFormAutoCalculatePnl] = useState(true);

  const openAddEntryForm = () => {
    const today = new Date().toISOString().slice(0, 10);
    setFormDate(today);
    setFormAsset("EURUSD");
    setFormDirection("LONG");
    setFormEntryPrice("");
    setFormExitPrice("");
    setFormStopLoss("");
    setFormTakeProfit("");
    setFormKillzone(true);
    setFormHtfBias(true);
    setFormScore(80);
    setFormClosedCandle(true);
    setFormProtoLimitEntry(true);
    setFormProtoAtrStopLoss(true);
    setFormProtoSotdRisk(true);
    setFormProtoProtectedTarget(true);
    setFormProtoTakePartials(true);
    setFormProtoTrailingStop(false);
    setFormAdherence("fully");
    setFormNotes("");
    setFormPostAnalysis("");
    setFormCustomPnlAmount("");
    setFormCustomPnlPercentage("");
    setFormAutoCalculatePnl(true);
    setEditingEntryId(null);
    setIsAddingEntry(true);
  };

  const openEditEntryForm = (entry: JournalEntry) => {
    setFormDate(entry.date);
    setFormAsset(entry.asset);
    setFormDirection(entry.direction);
    setFormEntryPrice(entry.entryPrice.toString());
    setFormExitPrice(entry.exitPrice.toString());
    setFormStopLoss(entry.stopLoss.toString());
    setFormTakeProfit(entry.takeProfit.toString());
    setFormKillzone(entry.killzone);
    setFormHtfBias(entry.htfBias);
    setFormScore(entry.smartMoneyScore);
    setFormClosedCandle(entry.closedCandle);
    setFormProtoLimitEntry(entry.protocols.limitEntry);
    setFormProtoAtrStopLoss(entry.protocols.atrStopLoss);
    setFormProtoSotdRisk(entry.protocols.sotdRisk);
    setFormProtoProtectedTarget(entry.protocols.protectedTarget);
    setFormProtoTakePartials(entry.protocols.takePartials);
    setFormProtoTrailingStop(entry.protocols.trailingStop);
    setFormAdherence(entry.adheredToMasterplan);
    setFormNotes(entry.notes);
    setFormPostAnalysis(entry.postTradeAnalysis);
    setFormCustomPnlAmount(entry.pnlAmount.toString());
    setFormCustomPnlPercentage(entry.pnlPercentage.toString());
    setFormAutoCalculatePnl(false);
    setEditingEntryId(entry.id);
    setIsAddingEntry(true);
  };

  const handleSaveEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formAsset || !formDate) {
      alert("Please fill in the required fields (Asset and Date).");
      return;
    }

    const entryPriceVal = parseFloat(formEntryPrice) || 0;
    const exitPriceVal = parseFloat(formExitPrice) || 0;
    const stopLossVal = parseFloat(formStopLoss) || 0;
    const takeProfitVal = parseFloat(formTakeProfit) || 0;

    let isWin = false;
    if (formDirection === "LONG") {
      isWin = exitPriceVal > entryPriceVal;
    } else {
      isWin = exitPriceVal < entryPriceVal;
    }

    let calculatedPct = 0;
    if (entryPriceVal > 0) {
      calculatedPct = ((exitPriceVal - entryPriceVal) / entryPriceVal) * (formDirection === "LONG" ? 1 : -1) * 100;
    }
    let calculatedAmt = calculatedPct * 1000; // standard Lot assumption on 100k account size

    const pnlPercentageVal = formAutoCalculatePnl ? calculatedPct : (parseFloat(formCustomPnlPercentage) || 0);
    const pnlAmountVal = formAutoCalculatePnl ? calculatedAmt : (parseFloat(formCustomPnlAmount) || 0);
    
    const finalIsWin = formAutoCalculatePnl ? isWin : (pnlAmountVal >= 0);

    const newEntry: JournalEntry = {
      id: editingEntryId || `journal-${Date.now()}`,
      date: formDate,
      asset: formAsset.toUpperCase(),
      direction: formDirection,
      entryPrice: entryPriceVal,
      exitPrice: exitPriceVal,
      stopLoss: stopLossVal,
      takeProfit: takeProfitVal,
      killzone: formKillzone,
      htfBias: formHtfBias,
      smartMoneyScore: formScore,
      closedCandle: formClosedCandle,
      protocols: {
        limitEntry: formProtoLimitEntry,
        atrStopLoss: formProtoAtrStopLoss,
        sotdRisk: formProtoSotdRisk,
        protectedTarget: formProtoProtectedTarget,
        takePartials: formProtoTakePartials,
        trailingStop: formProtoTrailingStop
      },
      adheredToMasterplan: formAdherence,
      notes: formNotes,
      postTradeAnalysis: formPostAnalysis,
      pnlAmount: pnlAmountVal,
      pnlPercentage: pnlPercentageVal,
      isWin: finalIsWin
    };

    if (editingEntryId) {
      setJournalEntries(prev => prev.map(item => item.id === editingEntryId ? newEntry : item));
    } else {
      setJournalEntries(prev => [newEntry, ...prev]);
    }

    setIsAddingEntry(false);
    setEditingEntryId(null);
  };

  const handleDeleteEntry = (id: string) => {
    if (confirm("Are you sure you want to delete this trade journal entry?")) {
      setJournalEntries(prev => prev.filter(item => item.id !== id));
    }
  };

  const handleImportAnalyzerToJournal = () => {
    let assetName = "EURUSD";
    const notesUpper = analyzerInputs.userNotes.toUpperCase();
    if (notesUpper.includes("GBPUSD")) assetName = "GBPUSD";
    else if (notesUpper.includes("NAS100")) assetName = "NAS100";
    else if (notesUpper.includes("XAUUSD")) assetName = "XAUUSD";
    else if (notesUpper.includes("USDCAD")) assetName = "USDCAD";

    const direction: "LONG" | "SHORT" = (analyzerInputs.weeklyBias === "bearish" || analyzerInputs.dailyBias === "bearish") ? "SHORT" : "LONG";

    const today = new Date().toISOString().slice(0, 10);
    setFormDate(today);
    setFormAsset(assetName);
    setFormDirection(direction);
    setFormEntryPrice("");
    setFormExitPrice("");
    setFormStopLoss("");
    setFormTakeProfit("");
    setFormKillzone(isKillzoneActive);
    setFormHtfBias(isBiasAligned);
    setFormScore(localScore);
    setFormClosedCandle(isCandleClosed);
    setFormProtoLimitEntry(true);
    setFormProtoAtrStopLoss(true);
    setFormProtoSotdRisk(true);
    setFormProtoProtectedTarget(true);
    setFormProtoTakePartials(localScore >= 80);
    setFormProtoTrailingStop(false);
    
    setFormAdherence(canLocalTrade ? "fully" : "partially");
    setFormNotes(`[Pre-planned from Analyzer]\nLive Local score was ${localScore}% (${localTier}).\n\nNotes from chart: ${analyzerInputs.userNotes}\n\nConfluences:\n- FVG/OB: ${analyzerInputs.fvgObDetails}\n- CHoCH/BOS: ${analyzerInputs.chochBosDetails}\n- SMT: ${analyzerInputs.smtDetails}\n- Volume: ${analyzerInputs.volumeDetails}`);
    setFormPostAnalysis("");
    setFormCustomPnlAmount("");
    setFormCustomPnlPercentage("");
    setFormAutoCalculatePnl(true);
    setEditingEntryId(null);
    setIsAddingEntry(true);
    setActiveTab("journal");
  };

  const handleImportAiToJournal = () => {
    if (!aiResponse) return;
    
    let assetName = "EURUSD";
    const notesUpper = analyzerInputs.userNotes.toUpperCase();
    if (notesUpper.includes("GBPUSD")) assetName = "GBPUSD";
    else if (notesUpper.includes("NAS100")) assetName = "NAS100";
    else if (notesUpper.includes("XAUUSD")) assetName = "XAUUSD";

    const direction: "LONG" | "SHORT" = aiResponse.filterHTFBias.direction === "SHORT ONLY" ? "SHORT" : "LONG";

    const today = new Date().toISOString().slice(0, 10);
    setFormDate(today);
    setFormAsset(assetName);
    setFormDirection(direction);
    setFormEntryPrice("");
    setFormExitPrice("");
    setFormStopLoss("");
    setFormTakeProfit("");
    setFormKillzone(aiResponse.filterKillzone.pass);
    setFormHtfBias(aiResponse.filterHTFBias.pass);
    setFormScore(aiResponse.filterSmartMoneyScore.score);
    setFormClosedCandle(aiResponse.filterClosedCandle.pass);
    setFormProtoLimitEntry(true);
    setFormProtoAtrStopLoss(true);
    setFormProtoSotdRisk(true);
    setFormProtoProtectedTarget(true);
    setFormProtoTakePartials(true);
    setFormProtoTrailingStop(false);
    
    setFormAdherence(aiResponse.overallPass ? "fully" : "no");
    setFormNotes(`[AI Pre-planned Setup]\nGemini analysis score: ${aiResponse.filterSmartMoneyScore.score}% (${aiResponse.filterSmartMoneyScore.tier}).\n\nNotes: ${analyzerInputs.userNotes}\n\nAI Assessment:\n${aiResponse.analysis}`);
    setFormPostAnalysis(`AI execution advice:\n- Stop Loss: ${aiResponse.executionPlan.stopLossAdvice}\n- Entry: ${aiResponse.executionPlan.entryAdvice}\n- Targets: ${aiResponse.executionPlan.targetsAdvice}`);
    setFormCustomPnlAmount("");
    setFormCustomPnlPercentage("");
    setFormAutoCalculatePnl(true);
    setEditingEntryId(null);
    setIsAddingEntry(true);
    setActiveTab("journal");
  };

  const handleImportSimToJournal = (trade: TradeSimulation) => {
    const today = new Date().toISOString().slice(0, 10);
    
    let assetName = "EURUSD";
    if (trade.setupName) {
      const parts = trade.setupName.split(" ");
      if (parts.length > 0) {
        assetName = parts[0];
      }
    }

    const direction = trade.direction;
    const entryPrice = assetName.includes("JPY") ? 150.00 : 1.08500;
    
    const isWin = trade.outcome !== "LOSS";
    let exitPrice = entryPrice;
    if (direction === "LONG") {
      exitPrice = isWin ? entryPrice + 0.00450 : entryPrice - 0.00150;
    } else {
      exitPrice = isWin ? entryPrice - 0.00450 : entryPrice + 0.00150;
    }

    setFormDate(today);
    setFormAsset(assetName);
    setFormDirection(direction);
    setFormEntryPrice(entryPrice.toString());
    setFormExitPrice(exitPrice.toString());
    setFormStopLoss((direction === "LONG" ? entryPrice - 0.00150 : entryPrice + 0.00150).toFixed(5));
    setFormTakeProfit((direction === "LONG" ? entryPrice + 0.00450 : entryPrice - 0.00450).toFixed(5));
    
    setFormKillzone(true);
    setFormHtfBias(true);
    setFormScore(trade.tier === "ELITE" ? 90 : trade.tier === "PRIME" ? 82 : 70);
    setFormClosedCandle(true);
    
    setFormProtoLimitEntry(true);
    setFormProtoAtrStopLoss(true);
    setFormProtoSotdRisk(true);
    setFormProtoProtectedTarget(isWin);
    setFormProtoTakePartials(isWin);
    setFormProtoTrailingStop(false);
    
    setFormAdherence("fully");
    setFormNotes(`[Simulated Trade #${trade.tradeNumber}]\nLogged from USME Prop Firm Challenge Simulator.\nSetup Tier: ${trade.tier}\nNotes: ${trade.notes}`);
    setFormPostAnalysis(`Simulated Result: ${trade.outcome}\nPnL Amount: $${trade.pnlAmount.toLocaleString()}\nPnL Percentage: ${trade.pnlPercentage.toFixed(2)}%\nTrailing Drawdown during trade was ${trade.trailingDrawdown.toFixed(2)}% from peak.`);
    
    setFormCustomPnlAmount(trade.pnlAmount.toString());
    setFormCustomPnlPercentage(trade.pnlPercentage.toString());
    setFormAutoCalculatePnl(false);
    
    setEditingEntryId(null);
    setIsAddingEntry(true);
    setActiveTab("journal");
  };

  // Initialize first setup on simulator enter
  useEffect(() => {
    if (!currentSetup) {
      setCurrentSetup(generateRandomSetup(1));
    }
  }, []);

  const handleNextSetup = () => {
    const nextId = simState.tradeHistory.length + 1;
    setCurrentSetup(generateRandomSetup(nextId));
  };

  const handleExecuteTrade = () => {
    if (!currentSetup) return;
    if (simState.isPassed || simState.isFailed) return;

    // Check pause rule (3 consecutive losses pause)
    if (simState.isPausedFor30m) {
      alert("⚠️ RESET RULE ACTIVE: You have suffered 3 consecutive losses. Pause for 30 minutes (Reset consecutive losses to proceed).");
      return;
    }

    // Determine position risk tier
    let riskPct = 0.2;
    if (currentSetup.tier === "ELITE") riskPct = 0.5;
    else if (currentSetup.tier === "PRIME") riskPct = 0.35;

    // Simulate outcome
    const outcomeResult = simulateTradeOutcome(currentSetup, simState.balance, simWinRate);

    const newBalance = simState.balance + outcomeResult.pnlAmount;
    const newPeak = Math.max(simState.peakEquity, newBalance);
    
    // Check Trailing drawdown (Limit is 8% of Peak Equity)
    // The peak drawdown limit is PeakEquity * 0.92 (meaning if we fall below 92% of the peak, we fail)
    const currentDrawdownAmountFromPeak = newPeak - newBalance;
    const currentDrawdownPct = (currentDrawdownAmountFromPeak / newPeak) * 100;
    const maxDrawdownReached = Math.max(simState.maxTrailingDrawdown, currentDrawdownPct);

    // Track consecutive losses
    const isLoss = outcomeResult.outcome === "LOSS";
    const consecutive = isLoss ? simState.consecutiveLosses + 1 : 0;

    // Daily & Weekly accumulations (for simplicity, we assume each trade represents a chunk of the day/week)
    // If a loss, let's add it. If a win, we adjust.
    const tradeDailyLoss = isLoss ? Math.abs(outcomeResult.pnlAmount) : 0;
    const newDailyLossTotal = isLoss ? simState.dailyLossTotal + tradeDailyLoss : Math.max(0, simState.dailyLossTotal - outcomeResult.pnlAmount);
    const newWeeklyLossTotal = isLoss ? simState.weeklyLossTotal + tradeDailyLoss : Math.max(0, simState.weeklyLossTotal - outcomeResult.pnlAmount);

    // Build history item
    const newTrade: TradeSimulation = {
      id: currentSetup.id,
      tradeNumber: simState.tradeHistory.length + 1,
      setupName: `${currentSetup.asset} (${currentSetup.tier})`,
      tier: currentSetup.tier,
      riskPercentage: riskPct,
      direction: Math.random() > 0.5 ? "LONG" : "SHORT", // mock direction for ledger
      outcome: outcomeResult.outcome,
      pnlAmount: outcomeResult.pnlAmount,
      pnlPercentage: outcomeResult.pnlPercentage,
      endingBalance: newBalance,
      peakEquity: newPeak,
      trailingDrawdown: currentDrawdownPct,
      notes: outcomeResult.notes
    };

    // Evaluate strict rule failures
    let isFailed = false;
    let failureReason = "";

    // Rule 1: Trailing drawdown > 8%
    if (currentDrawdownPct >= 8.0) {
      isFailed = true;
      failureReason = `💥 PEAK TRAILING DRAWDOWN BREACHED: Your balance dropped to $${newBalance.toLocaleString()} which is ${(currentDrawdownPct).toFixed(2)}% below your peak equity of $${newPeak.toLocaleString()}. Prop firms enforce a strict 8% maximum trailing drawdown from your peak equity.`;
    }
    // Rule 2: Daily drawdown > 1.5%
    else if (newDailyLossTotal >= (simState.accountSize * 0.015)) {
      isFailed = true;
      failureReason = `💥 DAILY DRAWDOWN LIMIT BREACHED: You accumulated $${newDailyLossTotal.toLocaleString()} of losses today. USME Risk Pillar 2 limits daily losses to a strict 1.5% max ($${(simState.accountSize * 0.015).toLocaleString()}).`;
    }
    // Rule 3: Weekly drawdown > 3.0%
    else if (newWeeklyLossTotal >= (simState.accountSize * 0.03)) {
      isFailed = true;
      failureReason = `💥 WEEKLY DRAWDOWN LIMIT BREACHED: You accumulated $${newWeeklyLossTotal.toLocaleString()} of losses this week. USME Risk Pillar 3 limits weekly losses to a strict 3.0% max ($${(simState.accountSize * 0.03).toLocaleString()}).`;
    }

    // Evaluate Pass conditions
    // Goal is 10% profit -> standard prop target
    const profitPct = ((newBalance - simState.accountSize) / simState.accountSize) * 100;
    const isPassed = !isFailed && profitPct >= 10.0;

    // Check reset rule (consecutive losses == 3)
    const mustPause = consecutive >= 3;

    // Set updated state
    setSimState((prev) => ({
      ...prev,
      balance: newBalance,
      peakEquity: newPeak,
      maxTrailingDrawdown: maxDrawdownReached,
      consecutiveLosses: consecutive,
      dailyLossTotal: newDailyLossTotal,
      weeklyLossTotal: newWeeklyLossTotal,
      tradeHistory: [...prev.tradeHistory, newTrade],
      isPassed,
      isFailed,
      failureReason,
      isPausedFor30m: mustPause
    }));

    if (isPassed) {
      setShowCertificate(true);
    }

    // Advance to next setup
    const nextId = simState.tradeHistory.length + 2;
    setCurrentSetup(generateRandomSetup(nextId));
  };

  const handleSkipSetup = () => {
    handleNextSetup();
  };

  const resetSimulator = () => {
    setSimState({
      accountSize: initialBalance,
      balance: initialBalance,
      peakEquity: initialBalance,
      maxTrailingDrawdown: 0,
      consecutiveLosses: 0,
      dailyLossTotal: 0,
      weeklyLossTotal: 0,
      tradeHistory: [],
      isPassed: false,
      isFailed: false,
      failureReason: "",
      isPausedFor30m: false
    });
    setShowCertificate(false);
    setCurrentSetup(generateRandomSetup(1));
  };

  const resetConsecutiveLosses = () => {
    setSimState((prev) => ({
      ...prev,
      consecutiveLosses: 0,
      isPausedFor30m: false
    }));
  };


  return (
    <div id="usme-root" className="min-h-screen bg-[#f0f2f5] text-[#0f172a] font-sans antialiased selection:bg-blue-600/10 selection:text-blue-900">
      
      {/* HEADER SECTION */}
      <header id="usme-header" className="border-b border-slate-200 bg-white/90 backdrop-blur-md sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="bg-slate-900 text-white px-3 py-1 rounded-lg font-bold text-lg tracking-tighter font-mono">USME</div>
            <div>
              <h1 className="text-sm font-semibold text-slate-500 uppercase tracking-widest leading-none">Foundation Workspace</h1>
              <p className="text-[10px] text-slate-400 font-mono">SNIPERTRADER v4.1 // INSTITUTIONAL FOOTPRINT</p>
            </div>
          </div>
          
          {/* Main Navigation Tabs */}
          <nav id="usme-nav" className="flex bg-slate-100 p-1 border border-slate-200/80 rounded-lg self-start md:self-auto overflow-x-auto max-w-full">
            <button
              id="tab-lessons"
              onClick={() => setActiveTab("lessons")}
              className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-md transition-all duration-200 whitespace-nowrap ${
                activeTab === "lessons" 
                  ? "bg-slate-900 text-white shadow-sm" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <BookOpen className="h-3.5 w-3.5" />
              1. Tutorial Lessons
            </button>
            <button
              id="tab-analyzer"
              onClick={() => setActiveTab("analyzer")}
              className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-md transition-all duration-200 whitespace-nowrap ${
                activeTab === "analyzer" 
                  ? "bg-slate-900 text-white shadow-sm" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <Sparkles className="h-3.5 w-3.5" />
              2. Confluence Analyzer
            </button>
            <button
              id="tab-sizer"
              onClick={() => setActiveTab("sizer")}
              className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-md transition-all duration-200 whitespace-nowrap ${
                activeTab === "sizer" 
                  ? "bg-slate-900 text-white shadow-sm" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <Calculator className="h-3.5 w-3.5" />
              3. Position Sizer
            </button>
            <button
              id="tab-simulator"
              onClick={() => setActiveTab("simulator")}
              className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-md transition-all duration-200 whitespace-nowrap ${
                activeTab === "simulator" 
                  ? "bg-slate-900 text-white shadow-sm" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <Award className="h-3.5 w-3.5" />
              4. Challenge Simulator
            </button>
            <button
              id="tab-journal"
              onClick={() => setActiveTab("journal")}
              className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-md transition-all duration-200 whitespace-nowrap ${
                activeTab === "journal" 
                  ? "bg-slate-900 text-white shadow-sm" 
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <BookMarked className="h-3.5 w-3.5" />
              5. Digital Trade Journal
            </button>
          </nav>
        </div>
      </header>

      {/* CORE CONTAINER */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        
        <AnimatePresence mode="wait">
          
          {/* TAB 1: LESSONS / SCRIPT GUIDE */}
          {activeTab === "lessons" && (
            <motion.div
              key="lessons-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8"
            >
              {/* Slide Navigation Rail */}
              <div className="lg:col-span-4 space-y-2.5">
                <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm">
                  <h3 className="font-semibold text-sm text-slate-800 font-display flex items-center gap-2">
                    <Activity className="h-4 w-4 text-slate-700" />
                    USME Training Syllabus
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">Click any chapter to jump directly to that mechanical core concept.</p>
                </div>
                
                <div className="space-y-1.5">
                  {tutorialScript.map((section, idx) => (
                    <button
                      key={section.id}
                      onClick={() => setActiveLessonIdx(idx)}
                      className={`w-full text-left p-3.5 rounded-lg border transition-all duration-200 flex items-center justify-between group ${
                        activeLessonIdx === idx 
                          ? "bg-blue-50/50 border-blue-200 text-blue-700 shadow-sm" 
                          : "bg-white border-slate-200 hover:bg-slate-50 text-slate-600"
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded transition-colors ${
                            activeLessonIdx === idx 
                              ? "bg-blue-100 text-blue-700" 
                              : "bg-slate-100 text-slate-500 group-hover:bg-slate-200"
                          }`}>
                            {section.timeRange}
                          </span>
                          <span className={`text-xs font-semibold ${activeLessonIdx === idx ? "text-blue-700" : "text-slate-500"}`}>
                            {section.title.split(":")[0]}
                          </span>
                        </div>
                        <p className="text-xs font-display font-medium line-clamp-1 text-slate-800">
                          {section.title.split(":").slice(1).join(":") || section.title}
                        </p>
                      </div>
                      <ChevronRight className={`h-4 w-4 transition-transform duration-200 ${activeLessonIdx === idx ? "translate-x-1 text-blue-600" : "text-slate-400 group-hover:text-slate-600"}`} />
                    </button>
                  ))}
                </div>
              </div>

              {/* Slide Display Viewer */}
              <div className="lg:col-span-8 space-y-6">
                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                  {/* Slide header */}
                  <div className="bg-slate-50 border-b border-slate-200 p-5 flex items-center justify-between">
                    <div className="space-y-1">
                      <span className="text-[10px] text-blue-600 font-mono tracking-widest uppercase font-bold">
                        CHAPTER {activeLessonIdx + 1} OF {tutorialScript.length} • {currentLesson.timeRange}
                      </span>
                      <h2 className="text-lg font-bold text-slate-900 font-display">
                        {currentLesson.title}
                      </h2>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        disabled={activeLessonIdx === 0}
                        onClick={() => setActiveLessonIdx(p => Math.max(0, p - 1))}
                        className="p-1.5 rounded-md border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 disabled:opacity-40 text-xs transition-colors"
                      >
                        Prev
                      </button>
                      <button
                        disabled={activeLessonIdx === tutorialScript.length - 1}
                        onClick={() => setActiveLessonIdx(p => Math.min(tutorialScript.length - 1, p + 1))}
                        className="p-1.5 rounded-md border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 disabled:opacity-40 text-xs transition-colors"
                      >
                        Next
                      </button>
                    </div>
                  </div>

                  {/* Interactive Visual/Diagram Stage */}
                  <div className="bg-slate-50 p-6 border-b border-slate-200/80 flex flex-col items-center justify-center min-h-[220px]">
                    {currentLesson.id === "intro" && (
                      <div className="text-center space-y-3">
                        <div className="inline-flex p-3 bg-blue-50 border border-blue-100 text-blue-600 rounded-full animate-bounce">
                          <ShieldCheck className="h-10 w-10" />
                        </div>
                        <h4 className="text-sm font-semibold text-slate-800 font-display">SniperTrader mechanical blueprint is armed.</h4>
                        <p className="text-xs text-slate-500 max-w-md mx-auto">Click through the syllabus tabs on the left to review the 4 filters, 6 execution protocols, and strict prop firm challenge risk models.</p>
                      </div>
                    )}

                    {currentLesson.id === "section1" && (
                      <div className="w-full max-w-lg space-y-4">
                        <div className="flex items-center justify-between text-xs font-mono text-slate-400">
                          <span>UNCONFIRMED SIGNAL (NO TRACE)</span>
                          <span>CONFIRMED FOOTPRINT (REACT)</span>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="border border-red-100 bg-red-50/50 p-3.5 rounded-lg flex flex-col justify-between h-28">
                            <div className="text-[10px] text-red-600 font-mono">❌ SPECULATION</div>
                            <p className="text-xs text-slate-700 font-medium">Predicting exact cycle bottoms based on indicators or gut feelings.</p>
                            <span className="text-[10px] text-red-500/70">Sub-50% probability, capital at risk.</span>
                          </div>
                          <div className="border border-blue-100 bg-blue-50/50 p-3.5 rounded-lg flex flex-col justify-between h-28">
                            <div className="text-[10px] text-blue-600 font-mono">✅ USME PROTOCOL</div>
                            <p className="text-xs text-slate-700 font-medium">Waiting for institutional displacement (FVG or SMT) before reacting.</p>
                            <span className="text-[10px] text-blue-500/70">Mechanical edge confirmed by footprint.</span>
                          </div>
                        </div>
                      </div>
                    )}

                    {currentLesson.id === "section2" && (
                      <div className="w-full max-w-xl space-y-4">
                        <h4 className="text-xs font-semibold text-slate-500 font-mono uppercase tracking-wider text-center">The 4-Step Entry Gateway</h4>
                        <div className="grid grid-cols-4 gap-2.5">
                          <div className="bg-white border border-slate-200 p-2.5 rounded text-center">
                            <div className="text-[10px] text-blue-600 font-mono font-bold">FILTER 1</div>
                            <div className="text-xs font-semibold text-slate-900 mt-1">Killzone</div>
                            <p className="text-[10px] text-slate-500 mt-0.5">London / NY Open only</p>
                          </div>
                          <div className="bg-white border border-slate-200 p-2.5 rounded text-center">
                            <div className="text-[10px] text-blue-600 font-mono font-bold">FILTER 2</div>
                            <div className="text-xs font-semibold text-slate-900 mt-1">HTF Bias</div>
                            <p className="text-[10px] text-slate-500 mt-0.5">W1 & D1 Must Align</p>
                          </div>
                          <div className="bg-white border border-slate-200 p-2.5 rounded text-center">
                            <div className="text-[10px] text-blue-600 font-mono font-bold">FILTER 3</div>
                            <div className="text-xs font-semibold text-slate-900 mt-1">SMS Score</div>
                            <p className="text-[10px] text-slate-500 mt-0.5">&gt;= 80% Confluence</p>
                          </div>
                          <div className="bg-white border border-slate-200 p-2.5 rounded text-center">
                            <div className="text-[10px] text-blue-600 font-mono font-bold">FILTER 4</div>
                            <div className="text-xs font-semibold text-slate-900 mt-1">Closed Bar</div>
                            <p className="text-[10px] text-slate-500 mt-0.5">Never enter forming bar</p>
                          </div>
                        </div>
                      </div>
                    )}

                    {currentLesson.id === "section3" && (
                      <div className="w-full max-w-md bg-white border border-slate-200 p-4 rounded-xl space-y-3 shadow-sm">
                        <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                          <span className="text-xs font-bold text-slate-800 font-display">6-Step Execution Timeline</span>
                          <span className="text-[10px] text-emerald-600 font-mono font-bold">Positive RR Matrix</span>
                        </div>
                        <div className="relative pl-6 space-y-2 text-xs font-mono">
                          <div className="absolute left-1.5 top-1 bottom-1 w-0.5 bg-slate-100"></div>
                          
                          <div className="relative">
                            <span className="absolute -left-[22px] top-0.5 h-3 w-3 rounded-full bg-blue-600 border-2 border-white"></span>
                            <span className="text-blue-600 font-bold">Step 1-2</span>: Limit Entry inside FVG. Stop Loss at 1.5x ATR.
                          </div>
                          <div className="relative">
                            <span className="absolute -left-[22px] top-0.5 h-3 w-3 rounded-full bg-slate-400 border-2 border-white"></span>
                            <span className="text-slate-700 font-bold">Step 3</span>: Position sized exactly to SOTD Tier (0.5% max risk).
                          </div>
                          <div className="relative">
                            <span className="absolute -left-[22px] top-0.5 h-3 w-3 rounded-full bg-emerald-500 border-2 border-white"></span>
                            <span className="text-emerald-600 font-bold">Step 4 (1.5R)</span>: Protected Target. Move Stop Loss to Breakeven.
                          </div>
                          <div className="relative">
                            <span className="absolute -left-[22px] top-0.5 h-3 w-3 rounded-full bg-emerald-500 border-2 border-white animate-pulse"></span>
                            <span className="text-emerald-600 font-bold">Step 5 (3.0R)</span>: Take Partial. Bank 50% profits, start trailing stop.
                          </div>
                        </div>
                      </div>
                    )}

                    {currentLesson.id === "section4" && (
                      <div className="w-full max-w-lg space-y-3">
                        <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-200 pb-1.5">
                          <span>PROP EVALUATION CEILINGS</span>
                          <span className="text-red-500 font-semibold font-mono">CRITICAL SAFETY ENVELOPE</span>
                        </div>
                        <div className="grid grid-cols-3 gap-3">
                          <div className="bg-white p-3 border border-slate-200 rounded text-center shadow-sm">
                            <div className="text-[10px] text-slate-400">1.5% DAILY LIMIT</div>
                            <div className="text-sm font-bold text-red-600 font-mono mt-1">$1,500 Max Loss</div>
                            <p className="text-[9px] text-slate-400 mt-0.5">Based on $100k Account</p>
                          </div>
                          <div className="bg-white p-3 border border-slate-200 rounded text-center shadow-sm">
                            <div className="text-[10px] text-slate-400">3% WEEKLY ALLOCATION</div>
                            <div className="text-sm font-bold text-red-600 font-mono mt-1">$3,000 Max Loss</div>
                            <p className="text-[9px] text-slate-400 mt-0.5">Step back until Monday</p>
                          </div>
                          <div className="bg-white p-3 border border-slate-200 rounded text-center shadow-sm">
                            <div className="text-[10px] text-slate-400">8% TRAILING LIMIT</div>
                            <div className="text-sm font-bold text-red-600 font-mono mt-1">$8,000 Max DD</div>
                            <p className="text-[9px] text-slate-400 mt-0.5">Measured from peak equity</p>
                          </div>
                        </div>
                      </div>
                    )}

                    {currentLesson.id === "section5" && (
                      <div className="w-full max-w-lg bg-white p-4 border border-slate-200 rounded-xl shadow-sm">
                        <h5 className="text-xs font-mono font-bold text-blue-600 uppercase tracking-wide border-b border-slate-100 pb-2 flex items-center justify-between">
                          <span>Mathematical Edge Projection</span>
                          <span>Expected Wins to Pass</span>
                        </h5>
                        <div className="grid grid-cols-3 gap-4 mt-3 text-center">
                          <div className="p-2 border border-slate-100 bg-slate-50/50 rounded">
                            <span className="text-[10px] text-slate-400 font-mono">ELITE SIGNALS</span>
                            <div className="text-xs font-bold text-emerald-600 mt-1">+1.5% Per Win</div>
                            <span className="text-[9px] text-slate-500 font-mono">Avg 3R with 0.5% risk</span>
                          </div>
                          <div className="p-2 border border-slate-100 bg-slate-50/50 rounded">
                            <span className="text-[10px] text-slate-400 font-mono">PRIME SIGNALS</span>
                            <div className="text-xs font-bold text-emerald-600 mt-1">+1.05% Per Win</div>
                            <span className="text-[9px] text-slate-500 font-mono">Avg 3R with 0.35% risk</span>
                          </div>
                          <div className="p-2 border border-slate-100 bg-slate-50/50 rounded">
                            <span className="text-[10px] text-slate-400 font-mono">TOTAL COMPLIANCE</span>
                            <div className="text-xs font-bold text-slate-800 mt-1">25 - 35 wins</div>
                            <span className="text-[9px] text-slate-500 font-mono">To secure 10% funding</span>
                          </div>
                        </div>
                      </div>
                    )}

                    {currentLesson.id === "section6" && (
                      <div className="w-full max-w-md bg-white p-4 border border-slate-200 rounded-xl space-y-2 shadow-sm">
                        <h5 className="text-xs font-bold font-display text-slate-800 border-b border-slate-100 pb-1.5 flex items-center gap-1.5">
                          <Flame className="h-3.5 w-3.5 text-blue-600" />
                          Four Daily Mindset Anchors
                        </h5>
                        <ul className="text-xs space-y-2 text-slate-600">
                          <li className="flex items-start gap-2">
                            <span className="h-1.5 w-1.5 rounded-full bg-blue-600 mt-1.5"></span>
                            <span>Did I strictly follow the 4-step setup filter?</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-1.5 w-1.5 rounded-full bg-blue-600 mt-1.5"></span>
                            <span>Did I respect my position sizing by SOTD tier?</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-1.5 w-1.5 rounded-full bg-blue-600 mt-1.5"></span>
                            <span>Did I manage the trade mechanically from entry to stop trailing?</span>
                          </li>
                        </ul>
                      </div>
                    )}

                    {currentLesson.id === "outro" && (
                      <div className="text-center space-y-3">
                        <div className="inline-flex p-3 bg-emerald-50 border border-emerald-100 text-emerald-600 rounded-full animate-pulse">
                          <Award className="h-10 w-10 text-emerald-600" />
                        </div>
                        <h4 className="text-sm font-semibold text-slate-800 font-display">Funded Account Certification ready for challenge.</h4>
                        <p className="text-xs text-slate-500 max-w-sm mx-auto">Use the Confluence Analyzer and Position Sizer tabs next to begin applying USME rules to real market setups.</p>
                      </div>
                    )}
                  </div>

                  {/* Audio Script Transcript Block */}
                  <div className="p-6 space-y-5 bg-slate-50/30">
                    <div className="space-y-2">
                      <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider font-mono flex items-center gap-1.5">
                        <Volume2 className="h-3.5 w-3.5 text-slate-700" />
                        Tutorial Voiceover Script (Synchronized)
                      </h4>
                      <p className="text-sm text-slate-700 leading-relaxed font-sans bg-white p-4 border border-slate-200 rounded-xl select-all">
                        "{currentLesson.voiceover}"
                      </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-3">
                      <div className="bg-white p-4 border border-slate-200 rounded-xl space-y-2 shadow-sm">
                        <h5 className="text-xs font-bold text-slate-800 font-display">Lesson Takeaways</h5>
                        <ul className="text-xs space-y-1.5 text-slate-500 list-disc list-inside">
                          {currentLesson.keyTakeaways.map((takeaway, i) => (
                            <li key={i} className="leading-relaxed">{takeaway}</li>
                          ))}
                        </ul>
                      </div>

                      <div className="bg-white p-4 border border-slate-200 rounded-xl space-y-2 flex flex-col justify-between shadow-sm">
                        <div>
                          <h5 className="text-xs font-bold text-blue-600 font-display flex items-center gap-1">
                            <ShieldCheck className="h-3.5 w-3.5 text-blue-600" />
                            Pro Strategy Tip
                          </h5>
                          <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                            {currentLesson.tips}
                          </p>
                        </div>
                        <div className="bg-slate-50 border border-slate-100 p-2.5 rounded-lg mt-3">
                          <span className="text-[9px] text-slate-400 font-mono uppercase tracking-widest block font-bold">FOOTPRINT SCIENCE</span>
                          <span className="text-[11px] text-slate-600 font-mono mt-0.5 block leading-tight">{currentLesson.technicalConcept}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50/50 border border-blue-100 p-4 rounded-xl flex items-center justify-between shadow-sm">
                  <div className="flex items-center gap-3">
                    <Sparkles className="h-5 w-5 text-blue-500 animate-pulse" />
                    <div>
                      <h4 className="text-xs font-bold text-slate-800 font-display">Ready to analyze a live market setup?</h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">Input parameters, calculate your confluence Smart Money Score, and get AI insights.</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab("analyzer")}
                    className="flex items-center gap-1 text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white px-3.5 py-2 rounded-lg shadow-sm transition-colors whitespace-nowrap"
                  >
                    Go to Analyzer
                    <ArrowRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 2: CONFLUENCE ANALYZER */}
          {activeTab === "analyzer" && (
            <motion.div
              key="analyzer-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="space-y-8"
            >
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                
                {/* Left Side: Setup Inputs form */}
                <div className="lg:col-span-7 space-y-6">
                  <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-6 shadow-sm">
                    <div>
                      <h2 className="text-base font-bold text-slate-800 font-display flex items-center gap-2">
                        <Calculator className="h-4 w-4 text-slate-700" />
                        Smart Money Score Confluence Workbook
                      </h2>
                      <p className="text-xs text-slate-500 mt-1">Check every parameter based on active charts to verify compliance with USME mechanical filters.</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {/* Session Killzone */}
                      <div className="space-y-1.5">
                        <label className="text-[11px] font-mono font-bold text-slate-500 uppercase tracking-wider block">1. Killzone Session</label>
                        <select
                          value={analyzerInputs.sessionTime}
                          onChange={(e) => setAnalyzerInputs(p => ({ ...p, sessionTime: e.target.value as any }))}
                          className="w-full bg-slate-50 text-xs border border-slate-200 rounded-lg p-2.5 text-slate-700 focus:outline-none focus:ring-1 focus:ring-slate-900 focus:border-slate-900 focus:bg-white transition-colors"
                        >
                          <option value="london">London (2:00 - 5:00 AM EST)</option>
                          <option value="ny_open">NY Open (8:30 - 11:00 AM EST)</option>
                          <option value="off_hours">Off-hours (Signals Discarded)</option>
                        </select>
                      </div>

                      {/* Weekly Bias */}
                      <div className="space-y-1.5">
                        <label className="text-[11px] font-mono font-bold text-slate-500 uppercase tracking-wider block">2. Weekly Bias</label>
                        <select
                          value={analyzerInputs.weeklyBias}
                          onChange={(e) => setAnalyzerInputs(p => ({ ...p, weeklyBias: e.target.value as any }))}
                          className="w-full bg-slate-50 text-xs border border-slate-200 rounded-lg p-2.5 text-slate-700 focus:outline-none focus:ring-1 focus:ring-slate-900 focus:border-slate-900 focus:bg-white transition-colors"
                        >
                          <option value="bullish">Bullish (Weekly Chart)</option>
                          <option value="bearish">Bearish (Weekly Chart)</option>
                          <option value="mixed">Mixed / Conflict</option>
                        </select>
                      </div>

                      {/* Daily Bias */}
                      <div className="space-y-1.5">
                        <label className="text-[11px] font-mono font-bold text-slate-500 uppercase tracking-wider block">3. Daily Bias</label>
                        <select
                          value={analyzerInputs.dailyBias}
                          onChange={(e) => setAnalyzerInputs(p => ({ ...p, dailyBias: e.target.value as any }))}
                          className="w-full bg-slate-50 text-xs border border-slate-200 rounded-lg p-2.5 text-slate-700 focus:outline-none focus:ring-1 focus:ring-slate-900 focus:border-slate-900 focus:bg-white transition-colors"
                        >
                          <option value="bullish">Bullish (Daily Chart)</option>
                          <option value="bearish">Bearish (Daily Chart)</option>
                          <option value="mixed">Mixed / Conflict</option>
                        </select>
                      </div>
                    </div>

                    <hr className="border-slate-100" />

                    <div className="space-y-5">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">Confluence Scoring Factors (20 points each)</h4>
                        <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-2 py-0.5 rounded-md">Total weight: 100 points</span>
                      </div>
                      
                      {/* Factor 1: FVG/OB */}
                      <div className="bg-slate-50/50 p-4 rounded-xl border border-slate-200/60 space-y-3">
                        <div className="flex items-start justify-between gap-2">
                          <div className="space-y-0.5">
                            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider font-bold block">FACTOR 1</span>
                            <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                              <Target className="h-3.5 w-3.5 text-slate-600" />
                              Fair Value Gap & Order Block Alignment
                            </span>
                          </div>
                          <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                            fvgObStatus === "yes" 
                              ? "bg-emerald-50 text-emerald-600" 
                              : fvgObStatus === "partial" 
                                ? "bg-amber-50 text-amber-600" 
                                : "bg-red-50 text-red-600"
                          }`}>
                            +{fvgObStatus === "yes" ? 20 : fvgObStatus === "partial" ? 10 : 0} pts
                          </span>
                        </div>
                        
                        {/* Interactive Toggles */}
                        <div className="grid grid-cols-3 gap-2">
                          <button
                            type="button"
                            onClick={() => setFvgObStatus("yes")}
                            className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                              fvgObStatus === "yes"
                                ? "bg-emerald-600 text-white border-emerald-600 shadow-sm"
                                : "bg-white text-slate-600 hover:bg-slate-50 border-slate-200"
                            }`}
                          >
                            Yes (Full)
                          </button>
                          <button
                            type="button"
                            onClick={() => setFvgObStatus("partial")}
                            className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                              fvgObStatus === "partial"
                                ? "bg-amber-500 text-white border-amber-500 shadow-sm"
                                : "bg-white text-slate-600 hover:bg-slate-50 border-slate-200"
                            }`}
                          >
                            Partial
                          </button>
                          <button
                            type="button"
                            onClick={() => setFvgObStatus("no")}
                            className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                              fvgObStatus === "no"
                                ? "bg-red-500 text-white border-red-500 shadow-sm"
                                : "bg-white text-slate-600 hover:bg-slate-50 border-slate-200"
                            }`}
                          >
                            No
                          </button>
                        </div>

                        {/* Optional context field */}
                        <input
                          type="text"
                          value={analyzerInputs.fvgObDetails}
                          onChange={(e) => setAnalyzerInputs(p => ({ ...p, fvgObDetails: e.target.value }))}
                          placeholder="Specify the timeframe or level (optional)..."
                          className="w-full bg-white text-xs border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 focus:outline-none focus:ring-1 focus:ring-slate-900 transition-colors"
                        />
                      </div>

                      {/* Factor 2: CHoCH/BOS */}
                      <div className="bg-slate-50/50 p-4 rounded-xl border border-slate-200/60 space-y-3">
                        <div className="flex items-start justify-between gap-2">
                          <div className="space-y-0.5">
                            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider font-bold block">FACTOR 2</span>
                            <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                              <TrendingUp className="h-3.5 w-3.5 text-slate-600" />
                              Change of Character / Break of Structure
                            </span>
                          </div>
                          <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                            chochBosStatus === "yes" 
                              ? "bg-emerald-50 text-emerald-600" 
                              : chochBosStatus === "partial" 
                                ? "bg-amber-50 text-amber-600" 
                                : "bg-red-50 text-red-600"
                          }`}>
                            +{chochBosStatus === "yes" ? 20 : chochBosStatus === "partial" ? 10 : 0} pts
                          </span>
                        </div>
                        
                        {/* Interactive Toggles */}
                        <div className="grid grid-cols-3 gap-2">
                          <button
                            type="button"
                            onClick={() => setChochBosStatus("yes")}
                            className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                              chochBosStatus === "yes"
                                ? "bg-emerald-600 text-white border-emerald-600 shadow-sm"
                                : "bg-white text-slate-600 hover:bg-slate-50 border-slate-200"
                            }`}
                          >
                            Yes (Full)
                          </button>
                          <button
                            type="button"
                            onClick={() => setChochBosStatus("partial")}
                            className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                              chochBosStatus === "partial"
                                ? "bg-amber-500 text-white border-amber-500 shadow-sm"
                                : "bg-white text-slate-600 hover:bg-slate-50 border-slate-200"
                            }`}
                          >
                            Partial
                          </button>
                          <button
                            type="button"
                            onClick={() => setChochBosStatus("no")}
                            className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                              chochBosStatus === "no"
                                ? "bg-red-500 text-white border-red-500 shadow-sm"
                                : "bg-white text-slate-600 hover:bg-slate-50 border-slate-200"
                            }`}
                          >
                            No
                          </button>
                        </div>

                        {/* Optional context field */}
                        <input
                          type="text"
                          value={analyzerInputs.chochBosDetails}
                          onChange={(e) => setAnalyzerInputs(p => ({ ...p, chochBosDetails: e.target.value }))}
                          placeholder="Describe the structural break or displacement (optional)..."
                          className="w-full bg-white text-xs border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 focus:outline-none focus:ring-1 focus:ring-slate-900 transition-colors"
                        />
                      </div>

                      {/* Factor 3: SMT Divergence */}
                      <div className="bg-slate-50/50 p-4 rounded-xl border border-slate-200/60 space-y-3">
                        <div className="flex items-start justify-between gap-2">
                          <div className="space-y-0.5">
                            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider font-bold block">FACTOR 3</span>
                            <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                              <Activity className="h-3.5 w-3.5 text-slate-600" />
                              SMT Divergence Alignment
                            </span>
                          </div>
                          <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                            smtStatus === "yes" 
                              ? "bg-emerald-50 text-emerald-600" 
                              : smtStatus === "partial" 
                                ? "bg-amber-50 text-amber-600" 
                                : "bg-red-50 text-red-600"
                          }`}>
                            +{smtStatus === "yes" ? 20 : smtStatus === "partial" ? 10 : 0} pts
                          </span>
                        </div>
                        
                        {/* Interactive Toggles */}
                        <div className="grid grid-cols-3 gap-2">
                          <button
                            type="button"
                            onClick={() => setSmtStatus("yes")}
                            className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                              smtStatus === "yes"
                                ? "bg-emerald-600 text-white border-emerald-600 shadow-sm"
                                : "bg-white text-slate-600 hover:bg-slate-50 border-slate-200"
                            }`}
                          >
                            Yes (Full)
                          </button>
                          <button
                            type="button"
                            onClick={() => setSmtStatus("partial")}
                            className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                              smtStatus === "partial"
                                ? "bg-amber-500 text-white border-amber-500 shadow-sm"
                                : "bg-white text-slate-600 hover:bg-slate-50 border-slate-200"
                            }`}
                          >
                            Partial
                          </button>
                          <button
                            type="button"
                            onClick={() => setSmtStatus("no")}
                            className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                              smtStatus === "no"
                                ? "bg-red-500 text-white border-red-500 shadow-sm"
                                : "bg-white text-slate-600 hover:bg-slate-50 border-slate-200"
                            }`}
                          >
                            No
                          </button>
                        </div>

                        {/* Optional context field */}
                        <input
                          type="text"
                          value={analyzerInputs.smtDetails}
                          onChange={(e) => setAnalyzerInputs(p => ({ ...p, smtDetails: e.target.value }))}
                          placeholder="Name the correlated assets or divergence zone (optional)..."
                          className="w-full bg-white text-xs border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 focus:outline-none focus:ring-1 focus:ring-slate-900 transition-colors"
                        />
                      </div>

                      {/* Factor 4: Volume Confirmation */}
                      <div className="bg-slate-50/50 p-4 rounded-xl border border-slate-200/60 space-y-3">
                        <div className="flex items-start justify-between gap-2">
                          <div className="space-y-0.5">
                            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider font-bold block">FACTOR 4</span>
                            <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                              <Volume2 className="h-3.5 w-3.5 text-slate-600" />
                              Volume Confirmation
                            </span>
                          </div>
                          <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                            volumeStatus === "yes" 
                              ? "bg-emerald-50 text-emerald-600" 
                              : volumeStatus === "partial" 
                                ? "bg-amber-50 text-amber-600" 
                                : "bg-red-50 text-red-600"
                          }`}>
                            +{volumeStatus === "yes" ? 20 : volumeStatus === "partial" ? 10 : 0} pts
                          </span>
                        </div>
                        
                        {/* Interactive Toggles */}
                        <div className="grid grid-cols-3 gap-2">
                          <button
                            type="button"
                            onClick={() => setVolumeStatus("yes")}
                            className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                              volumeStatus === "yes"
                                ? "bg-emerald-600 text-white border-emerald-600 shadow-sm"
                                : "bg-white text-slate-600 hover:bg-slate-50 border-slate-200"
                            }`}
                          >
                            Yes (Full)
                          </button>
                          <button
                            type="button"
                            onClick={() => setVolumeStatus("partial")}
                            className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                              volumeStatus === "partial"
                                ? "bg-amber-500 text-white border-amber-500 shadow-sm"
                                : "bg-white text-slate-600 hover:bg-slate-50 border-slate-200"
                            }`}
                          >
                            Partial
                          </button>
                          <button
                            type="button"
                            onClick={() => setVolumeStatus("no")}
                            className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                              volumeStatus === "no"
                                ? "bg-red-500 text-white border-red-500 shadow-sm"
                                : "bg-white text-slate-600 hover:bg-slate-50 border-slate-200"
                            }`}
                          >
                            No
                          </button>
                        </div>

                        {/* Optional context field */}
                        <input
                          type="text"
                          value={analyzerInputs.volumeDetails}
                          onChange={(e) => setAnalyzerInputs(p => ({ ...p, volumeDetails: e.target.value }))}
                          placeholder="Describe volume behavior or indicator spikes (optional)..."
                          className="w-full bg-white text-xs border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 focus:outline-none focus:ring-1 focus:ring-slate-900 transition-colors"
                        />
                      </div>

                      {/* Factor 5: HTF Bias Alignment */}
                      <div className="bg-slate-50/50 p-4 rounded-xl border border-slate-200/60 space-y-3">
                        <div className="flex items-start justify-between gap-2">
                          <div className="space-y-0.5">
                            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider font-bold block">FACTOR 5</span>
                            <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                              <ShieldCheck className="h-3.5 w-3.5 text-slate-600" />
                              Higher Timeframe Alignment
                            </span>
                          </div>
                          <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                            htfStatus === "yes" 
                              ? "bg-emerald-50 text-emerald-600" 
                              : htfStatus === "partial" 
                                ? "bg-amber-50 text-amber-600" 
                                : "bg-red-50 text-red-600"
                          }`}>
                            +{htfStatus === "yes" ? 20 : htfStatus === "partial" ? 10 : 0} pts
                          </span>
                        </div>
                        
                        {/* Interactive Toggles */}
                        <div className="grid grid-cols-3 gap-2">
                          <button
                            type="button"
                            onClick={() => handleHtfStatusChange("yes")}
                            className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                              htfStatus === "yes"
                                ? "bg-emerald-600 text-white border-emerald-600 shadow-sm"
                                : "bg-white text-slate-600 hover:bg-slate-50 border-slate-200"
                            }`}
                          >
                            Yes (Full)
                          </button>
                          <button
                            type="button"
                            onClick={() => handleHtfStatusChange("partial")}
                            className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                              htfStatus === "partial"
                                ? "bg-amber-500 text-white border-amber-500 shadow-sm"
                                : "bg-white text-slate-600 hover:bg-slate-50 border-slate-200"
                            }`}
                          >
                            Partial
                          </button>
                          <button
                            type="button"
                            onClick={() => handleHtfStatusChange("no")}
                            className={`py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                              htfStatus === "no"
                                ? "bg-red-500 text-white border-red-500 shadow-sm"
                                : "bg-white text-slate-600 hover:bg-slate-50 border-slate-200"
                            }`}
                          >
                            No
                          </button>
                        </div>
                        
                        <p className="text-[10px] text-slate-500 font-mono leading-tight">
                          Syncs with Weekly Bias ({analyzerInputs.weeklyBias}) and Daily Bias ({analyzerInputs.dailyBias}) above.
                        </p>
                      </div>
                    </div>

                    <hr className="border-slate-100" />

                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-50 p-4 border border-slate-200 rounded-xl">
                      <div className="flex items-start gap-3">
                        <input
                          type="checkbox"
                          id="closed-candle-rule-check"
                          checked={analyzerInputs.closedCandle}
                          onChange={(e) => setAnalyzerInputs(p => ({ ...p, closedCandle: e.target.checked }))}
                          className="mt-1 h-4 w-4 bg-white border-slate-300 text-slate-900 focus:ring-slate-900/20 rounded cursor-pointer"
                        />
                        <label htmlFor="closed-candle-rule-check" className="text-xs text-slate-600 cursor-pointer">
                          <span className="font-bold text-slate-800 block">Filter 4 — The Closed Candle Rule</span>
                          I will only enter after the signal candle is fully CLOSED. I will not trade forming candles.
                        </label>
                      </div>
                      <div className={`text-xs font-mono font-bold px-2 py-1 rounded text-center shrink-0 ${analyzerInputs.closedCandle ? "bg-emerald-50 text-emerald-600 border border-emerald-200" : "bg-red-50 text-red-600 border border-red-100 animate-pulse"}`}>
                        {analyzerInputs.closedCandle ? "PASSED RULE" : "CLOSED MANDATORY"}
                      </div>
                    </div>

                    {/* Raw Text Notes Context */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-600 block">Setup Raw Notes & Chart Context (Pasted details for AI Analysis)</label>
                      <textarea
                        value={analyzerInputs.userNotes}
                        onChange={(e) => setAnalyzerInputs(p => ({ ...p, userNotes: e.target.value }))}
                        rows={3}
                        className="w-full bg-slate-50 text-xs border border-slate-200 rounded-lg p-2.5 text-slate-700 focus:outline-none focus:ring-1 focus:ring-slate-900 focus:bg-white transition-colors"
                        placeholder="Add key observations, currency asset, or raw market details. Our AI Assistant parses this context to confirm mechanical score alignment..."
                      />
                    </div>

                    <div className="flex flex-col sm:flex-row gap-3 pt-2">
                      <button
                        onClick={handleAiAnalysis}
                        disabled={isAiLoading}
                        className="flex-1 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-200 text-white disabled:text-slate-400 font-semibold text-xs py-3 px-4 rounded-lg flex items-center justify-center gap-2 shadow-sm transition-all"
                      >
                        {isAiLoading ? (
                          <>
                            <div className="h-3.5 w-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                            <span>Analyzing Setup with USME AI Copilot...</span>
                          </>
                        ) : (
                          <>
                            <Sparkles className="h-4 w-4 text-white" />
                            <span>Run AI Institutional Audit (Gemini)</span>
                          </>
                        )}
                      </button>
                    </div>

                    {aiError && (
                      <div className="bg-red-50 border border-red-100 p-4 rounded-lg text-xs text-red-600 flex items-start gap-3">
                        <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5 text-red-500" />
                        <div className="space-y-1">
                          <p className="font-bold">Institutional Server Offline</p>
                          <p>{aiError}</p>
                          <p className="text-slate-500 mt-1">Please ensure your Gemini API Key is entered in the Secrets panel in the Settings menu.</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Right Side: Score Card / Live mechanical check */}
                <div className="lg:col-span-5 space-y-6">
                  
                  {/* Live mechanical score card */}
                  <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-6 shadow-sm">
                    <div>
                      <span className="text-[9px] text-slate-400 font-mono tracking-wider uppercase font-bold">REAL-TIME CONFLUENCE TELEMETRY</span>
                      <h3 className="text-sm font-bold text-slate-800 font-display mt-0.5">Live Local USME Scorecard</h3>
                    </div>

                    {/* Circular Indicator */}
                    <div className="flex flex-col items-center justify-center py-4 bg-slate-50 border border-slate-200 rounded-xl relative overflow-hidden">
                      <div className="absolute inset-0 bg-radial-gradient from-blue-500/5 to-transparent pointer-events-none"></div>
                      
                      <div className="relative flex items-center justify-center">
                        {/* Radial Circle representation */}
                        <div className="h-28 w-28 rounded-full border-4 border-slate-200 bg-white flex flex-col items-center justify-center relative">
                          <span className="text-3xl font-mono font-bold text-slate-850">{localScore}%</span>
                          <span className="text-[9px] text-slate-400 font-mono uppercase tracking-widest mt-0.5">SCORE</span>
                        </div>
                      </div>

                      <div className="text-center mt-4 space-y-1">
                        <span className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded-full ${
                          localTier === "ELITE" 
                            ? "bg-slate-900 text-white border border-slate-900" 
                            : localTier === "PRIME" 
                              ? "bg-blue-50 text-blue-600 border border-blue-200" 
                              : "bg-slate-100 text-slate-500 border border-slate-200"
                        }`}>
                          {localTier} TIER SIGNAL
                        </span>
                        <p className="text-[10px] text-slate-500 max-w-xs px-4">
                          {localScore >= 80 
                            ? "Passes USME Prime baseline threshold. Proceed to Position Sizer." 
                            : "⚠️ REJECTED: Under USME rules, any signal score below 80% is classified as standardized and MUST be skipped."
                          }
                        </p>
                      </div>
                    </div>

                    {/* 4 Filters checklist */}
                    <div className="space-y-3.5">
                      <h4 className="text-[11px] font-mono font-bold text-slate-400 uppercase tracking-widest">GATEWAY FILTERS CHECKLIST</h4>
                      
                      {/* Filter 1: Killzone */}
                      <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200/60 rounded-lg">
                        <div className="flex items-center gap-2.5">
                          <div className={`p-1.5 rounded-md ${isKillzoneActive ? "bg-emerald-50" : "bg-red-50"}`}>
                            <Clock className={`h-4 w-4 ${isKillzoneActive ? "text-emerald-600" : "text-red-500 animate-pulse"}`} />
                          </div>
                          <div>
                            <span className="text-xs font-bold text-slate-700 block">Killzone Confirmation</span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {analyzerInputs.sessionTime === "london" ? "London Session (2:00-5:00 AM EST)" : analyzerInputs.sessionTime === "ny_open" ? "NY Open Session (8:30-11:00 AM EST)" : "Off-hours / Outside Volume Window"}
                            </span>
                          </div>
                        </div>
                        <div>
                          {isKillzoneActive ? (
                            <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                          ) : (
                            <XCircle className="h-5 w-5 text-red-500" />
                          )}
                        </div>
                      </div>

                      {/* Filter 2: HTF Bias */}
                      <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200/60 rounded-lg">
                        <div className="flex items-center gap-2.5">
                          <div className={`p-1.5 rounded-md ${isBiasAligned ? "bg-emerald-50" : "bg-red-50"}`}>
                            <TrendingUp className={`h-4 w-4 ${isBiasAligned ? "text-emerald-600" : "text-red-500 animate-pulse"}`} />
                          </div>
                          <div>
                            <span className="text-xs font-bold text-slate-700 block">HTF Bias Agreement</span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              Weekly: {analyzerInputs.weeklyBias.toUpperCase()} • Daily: {analyzerInputs.dailyBias.toUpperCase()}
                            </span>
                          </div>
                        </div>
                        <div>
                          {isBiasAligned ? (
                            <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                          ) : (
                            <XCircle className="h-5 w-5 text-red-500" />
                          )}
                        </div>
                      </div>

                      {/* Filter 3: Smart Money Score */}
                      <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200/60 rounded-lg">
                        <div className="flex items-center gap-2.5">
                          <div className={`p-1.5 rounded-md ${isScoreAcceptable ? "bg-emerald-50" : "bg-red-50"}`}>
                            <Activity className={`h-4 w-4 ${isScoreAcceptable ? "text-emerald-600" : "text-red-500 animate-pulse"}`} />
                          </div>
                          <div>
                            <span className="text-xs font-bold text-slate-700 block">Institutional Score ({localScore}%)</span>
                            <span className="text-[10px] text-slate-400 font-mono">Requires minimum 80% to qualify</span>
                          </div>
                        </div>
                        <div>
                          {isScoreAcceptable ? (
                            <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                          ) : (
                            <XCircle className="h-5 w-5 text-red-500" />
                          )}
                        </div>
                      </div>

                      {/* Filter 4: Closed Candle */}
                      <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200/60 rounded-lg">
                        <div className="flex items-center gap-2.5">
                          <div className={`p-1.5 rounded-md ${isCandleClosed ? "bg-emerald-50" : "bg-red-50"}`}>
                            <ShieldCheck className={`h-4 w-4 ${isCandleClosed ? "text-emerald-600" : "text-red-500 animate-pulse"}`} />
                          </div>
                          <div>
                            <span className="text-xs font-bold text-slate-700 block">Closed Candle Rule</span>
                            <span className="text-[10px] text-slate-400 font-mono">Signals on unclosed candles are discarded</span>
                          </div>
                        </div>
                        <div>
                          {isCandleClosed ? (
                            <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                          ) : (
                            <XCircle className="h-5 w-5 text-red-500" />
                          )}
                        </div>
                      </div>
                    </div>

                    <div className={`p-4 border rounded-xl text-xs flex flex-col justify-between gap-3 ${canLocalTrade ? "bg-emerald-50 border-emerald-200 text-emerald-800" : "bg-red-50 border-red-100 text-red-800"}`}>
                      <div className="flex items-start gap-2.5">
                        <AlertTriangle className={`h-4 w-4 shrink-0 mt-0.5 ${canLocalTrade ? "text-emerald-600" : "text-red-500 animate-pulse"}`} />
                        <div>
                          <p className="font-bold">{canLocalTrade ? "MECHANICAL EDGE COGNITION: APPROVED" : "TRADE SETUP REJECTED"}</p>
                          <p className="text-[11px] text-slate-500 mt-1">
                            {canLocalTrade 
                              ? "Every entry gateway has approved compliance. You can advance to the Position Sizer to compute exact lot allocation." 
                              : "This trade setup cannot be executed. You must wait for active sessions, higher timeframe bias alignment, closed signal candles, and confluences totaling 80%+."
                            }
                          </p>
                        </div>
                      </div>
                      {canLocalTrade && (
                        <button
                          onClick={() => {
                            setSizerTier(localTier);
                            setActiveTab("sizer");
                          }}
                          className="w-full bg-slate-900 text-white font-semibold py-1.5 rounded-lg text-center text-xs hover:bg-slate-800 transition-all shadow-sm"
                        >
                          Import SOTD ({localTier}) into Position Sizer
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={handleImportAnalyzerToJournal}
                        className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-1.5 rounded-lg text-center text-xs transition-all border border-slate-200"
                      >
                        📖 Log Setup as Trade Plan in Journal
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* AI Gemini Analysis Response Display Area */}
              <AnimatePresence>
                {isAiLoading && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="bg-white border border-slate-200 p-8 rounded-xl flex flex-col items-center justify-center text-center space-y-4 shadow-sm"
                  >
                    <div className="h-10 w-10 border-4 border-slate-900 border-t-transparent rounded-full animate-spin"></div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-bold text-slate-800 font-display">Executing Smart Money Core Analyzer...</h4>
                      <p className="text-xs text-blue-600 font-mono tracking-widest">{loadingPhrases[loadingStep]}</p>
                    </div>
                    <p className="text-xs text-slate-500 max-w-md">Gemini is compiling SMT divergence indicators, Fair Value displacement parameters, and checking prop firm challenge metrics to output a structured mechanical execution sheet.</p>
                  </motion.div>
                )}

                {aiResponse && (
                  <motion.div
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm"
                  >
                    <div className="bg-slate-50 border-b border-slate-100 p-5 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Sparkles className="h-5 w-5 text-slate-700" />
                        <div>
                          <h3 className="font-bold text-sm text-slate-800 font-display">USME AI Institutional Audit Report</h3>
                          <p className="text-[10px] text-slate-500">Formulated under the SniperTrader ICT mechanical trading handbook</p>
                        </div>
                      </div>
                      <span className={`text-xs font-mono font-bold px-3 py-1 rounded-full ${aiResponse.overallPass ? "bg-emerald-50 text-emerald-600 border border-emerald-200" : "bg-red-50 text-red-600 border border-red-100"}`}>
                        {aiResponse.overallPass ? "PASSED USME gateway" : "REJECTED BY RULES"}
                      </span>
                    </div>

                    <div className="p-6 space-y-6">
                      
                      {/* Analysis Block */}
                      <div className="bg-slate-50 p-4 border border-slate-100 rounded-xl space-y-2">
                        <span className="text-[9px] text-slate-400 font-mono uppercase tracking-widest font-bold">EXECUTIVE ASSESSMENTS</span>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          {aiResponse.analysis}
                        </p>
                      </div>

                      {/* Score breakups */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                        
                        {/* Confluence scores */}
                        <div className="md:col-span-2 space-y-3.5">
                          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">CONFLUENCE INDEX CONSTITUENTS</h4>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            {aiResponse.filterSmartMoneyScore.factors.map((factor, i) => (
                              <div key={i} className="p-3 bg-slate-50 border border-slate-100 rounded-lg flex flex-col justify-between h-24 shadow-sm">
                                <div className="flex items-center justify-between">
                                  <span className="text-xs font-bold text-slate-700 line-clamp-1">{factor.name}</span>
                                  <span className="text-xs font-mono font-bold text-slate-900">{factor.score}/20</span>
                                </div>
                                <p className="text-[10px] text-slate-500 line-clamp-2 mt-1 leading-normal">{factor.details}</p>
                                <div className="w-full bg-slate-200 h-1 rounded-full overflow-hidden mt-1.5">
                                  <div className="bg-slate-800 h-1" style={{ width: `${(factor.score / 20) * 100}%` }}></div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Gateway filters */}
                        <div className="space-y-3.5">
                          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">GATE AUDIT DETAILS</h4>
                          <div className="space-y-2 text-xs">
                            <div className="p-2.5 bg-slate-50 border border-slate-100 rounded-lg space-y-1">
                              <div className="flex items-center justify-between">
                                <span className="font-bold text-slate-700">Killzone</span>
                                <span className={aiResponse.filterKillzone.pass ? "text-emerald-600 font-bold" : "text-red-500 font-bold"}>
                                  {aiResponse.filterKillzone.pass ? "PASS" : "FAIL"}
                                </span>
                              </div>
                              <p className="text-[10px] text-slate-500 leading-normal">{aiResponse.filterKillzone.details}</p>
                            </div>
                            <div className="p-2.5 bg-slate-50 border border-slate-100 rounded-lg space-y-1">
                              <div className="flex items-center justify-between">
                                <span className="font-bold text-slate-700">Bias alignment</span>
                                <span className={aiResponse.filterHTFBias.pass ? "text-emerald-600 font-bold" : "text-red-500 font-bold"}>
                                  {aiResponse.filterHTFBias.pass ? "PASS" : "FAIL"}
                                </span>
                              </div>
                              <p className="text-[10px] text-slate-500 leading-normal">{aiResponse.filterHTFBias.details}</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Execution Blueprint Block */}
                      <div className="bg-slate-50 p-5 border border-slate-100 rounded-xl space-y-4">
                        <div className="flex items-center justify-between border-b border-slate-200/65 pb-2.5">
                          <h4 className="text-xs font-mono font-bold text-slate-800 uppercase tracking-widest">USME EXECUTION PROTOCOLS</h4>
                          <span className="text-[10px] text-slate-500 font-mono">Suggested Risk: {aiResponse.executionPlan.riskPercentage}%</span>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 text-xs">
                          <div className="space-y-1">
                            <span className="text-slate-800 font-bold">1. Entry Location</span>
                            <p className="text-slate-500 leading-relaxed text-[11px]">{aiResponse.executionPlan.entryAdvice}</p>
                          </div>
                          <div className="space-y-1">
                            <span className="text-slate-700 font-bold">2. Protection (SL)</span>
                            <p className="text-slate-500 leading-relaxed text-[11px]">{aiResponse.executionPlan.stopLossAdvice}</p>
                          </div>
                          <div className="space-y-1">
                            <span className="text-slate-800 font-bold">3. Targets Plan</span>
                            <p className="text-slate-500 leading-relaxed text-[11px]">{aiResponse.executionPlan.targetsAdvice}</p>
                          </div>
                        </div>
                      </div>

                      {/* Prop Context Advice */}
                      <div className="bg-blue-50/50 p-4 border border-blue-100 rounded-xl text-xs space-y-1.5">
                        <h4 className="font-bold text-slate-850 font-display flex items-center gap-1.5">
                          <Briefcase className="h-4 w-4 text-slate-700" />
                          Prop Challenge Risk Calibration
                        </h4>
                        <p className="text-slate-600 leading-relaxed text-[11px]">
                          {aiResponse.propChallengeContext}
                        </p>
                      </div>

                      <div className="flex justify-end gap-2.5 pt-2">
                        <button
                          type="button"
                          onClick={handleImportAiToJournal}
                          className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs px-4 py-2 rounded-lg transition-all border border-slate-200"
                        >
                          📖 Log AI Analysis as Trade Plan
                        </button>
                        <button
                          onClick={() => {
                            setSizerTier(aiResponse.filterSmartMoneyScore.tier);
                            setActiveTab("sizer");
                          }}
                          className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-4 py-2 rounded-lg shadow-sm transition-all"
                        >
                          Send Parameters to Position Sizer
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )}

          {/* TAB 3: POSITION SIZER */}
          {activeTab === "sizer" && (
            <motion.div
              key="sizer-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8"
            >
              
              {/* Left Column: Sizer Inputs */}
              <div className="lg:col-span-5 space-y-6">
                <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-6 shadow-sm">
                  <div>
                    <h2 className="text-base font-bold text-slate-800 font-display flex items-center gap-2">
                      <Calculator className="h-4 w-4 text-slate-750" />
                      Mechanical Lot size Calculator
                    </h2>
                    <p className="text-xs text-slate-500 mt-1">SOTD (Signal of the Day) sizing adjusts risk by confluence tier automatically.</p>
                  </div>

                  {/* Sizer parameters */}
                  <div className="space-y-4">
                    {/* Account Balance preset and input */}
                    <div className="space-y-2">
                      <label className="text-xs font-semibold text-slate-600 block">Account Size ($)</label>
                      <input
                        type="number"
                        value={sizerAccountBalance}
                        onChange={(e) => setSizerAccountBalance(Number(e.target.value))}
                        className="w-full bg-slate-50 text-xs border border-slate-200 rounded-lg p-2.5 text-slate-700 focus:outline-none focus:ring-1 focus:ring-slate-900 focus:bg-white transition-colors"
                      />
                      <div className="flex gap-1.5 flex-wrap">
                        {[10000, 25000, 50000, 100000, 200000].map((preset) => (
                          <button
                            key={preset}
                            onClick={() => setSizerAccountBalance(preset)}
                            className={`text-[10px] font-mono px-2 py-1 rounded transition-colors ${
                              sizerAccountBalance === preset 
                                ? "bg-slate-900 border border-slate-900 text-white" 
                                : "bg-slate-50 hover:bg-slate-100 text-slate-500 border border-slate-200"
                            }`}
                          >
                            ${preset.toLocaleString()}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* SOTD Tier */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-600 block">SOTD Signal Tier</label>
                      <div className="grid grid-cols-3 gap-2 text-center text-xs">
                        {(["ELITE", "PRIME", "STANDARD"] as const).map((tier) => (
                          <button
                            key={tier}
                            onClick={() => setSizerTier(tier)}
                            className={`p-2.5 rounded-lg border font-bold transition-all ${
                              sizerTier === tier 
                                ? "bg-slate-900 border border-slate-900 text-white" 
                                : "bg-slate-50 border border-slate-200 hover:bg-slate-100 text-slate-500"
                            }`}
                          >
                            {tier}
                            <span className={`block text-[9px] font-mono font-normal mt-0.5 ${sizerTier === tier ? "text-slate-300" : "text-slate-400"}`}>
                              {tier === "ELITE" ? "0.5% risk" : tier === "PRIME" ? "0.35% risk" : "0.2% risk"}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>

                    <hr className="border-slate-100" />

                    {/* Asset Mode */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-600 block">Asset Calculation Method</label>
                      <div className="grid grid-cols-2 gap-2 text-center text-xs">
                        <button
                          onClick={() => setSizerAssetType("forex")}
                          className={`p-2.5 rounded-lg border font-bold transition-all ${
                            sizerAssetType === "forex" 
                              ? "bg-slate-900 border border-slate-900 text-white" 
                              : "bg-slate-50 border border-slate-200 hover:bg-slate-100 text-slate-500"
                          }`}
                        >
                          Forex (Pips)
                          <span className={`block text-[9px] font-mono font-normal mt-0.5 ${sizerAssetType === "forex" ? "text-slate-300" : "text-slate-400"}`}>Lot size formula</span>
                        </button>
                        <button
                          onClick={() => setSizerAssetType("crypto_stock_indices")}
                          className={`p-2.5 rounded-lg border font-bold transition-all ${
                            sizerAssetType === "crypto_stock_indices" 
                              ? "bg-slate-900 border border-slate-900 text-white" 
                              : "bg-slate-50 border border-slate-200 hover:bg-slate-100 text-slate-500"
                          }`}
                        >
                          Crypto / Stocks / Index
                          <span className={`block text-[9px] font-mono font-normal mt-0.5 ${sizerAssetType === "crypto_stock_indices" ? "text-slate-300" : "text-slate-400"}`}>Direct price difference</span>
                        </button>
                      </div>
                    </div>

                    {/* Stop Distance and Prices */}
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-slate-600 block">Entry Price</label>
                        <input
                          type="number"
                          step="any"
                          value={sizerEntryPrice}
                          onChange={(e) => setSizerEntryPrice(Number(e.target.value))}
                          className="w-full bg-slate-50 text-xs border border-slate-200 rounded-lg p-2.5 text-slate-700 focus:outline-none focus:ring-1 focus:ring-slate-900 focus:bg-white transition-colors"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-slate-600 block">
                          {sizerAssetType === "forex" ? "Stop Loss (Pips)" : "Stop Loss (Price Pt)"}
                        </label>
                        <input
                          type="number"
                          value={sizerStopLossDist}
                          onChange={(e) => setSizerStopLossDist(Number(e.target.value))}
                          className="w-full bg-slate-50 text-xs border border-slate-200 rounded-lg p-2.5 text-slate-700 focus:outline-none focus:ring-1 focus:ring-slate-900 focus:bg-white transition-colors"
                        />
                      </div>
                    </div>

                    {sizerAssetType === "forex" && (
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-slate-600 block">Pip Value ($ per Lot)</label>
                        <select
                          value={sizerPipVal}
                          onChange={(e) => setSizerPipVal(Number(e.target.value))}
                          className="w-full bg-slate-50 text-xs border border-slate-200 rounded-lg p-2.5 text-slate-700 focus:outline-none focus:ring-1 focus:ring-slate-900 focus:bg-white transition-colors"
                        >
                          <option value={10}>$10.00 (Standard Lot for EURUSD, GBPUSD)</option>
                          <option value={1}>$1.00 (Micro Pip Value)</option>
                          <option value={5}>$5.00 (Crosses / Custom)</option>
                        </select>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Right Column: Execution Output Details */}
              <div className="lg:col-span-7 space-y-6">
                
                {/* Result Sizer Block */}
                <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-6 shadow-sm">
                  <div>
                    <span className="text-[9px] text-slate-400 font-mono tracking-wider uppercase font-bold">CALCULATED ALLOCATION BLUEPRINT</span>
                    <h3 className="text-sm font-bold text-slate-800 font-display mt-0.5">Sizing & Target Levels</h3>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div className="bg-slate-50 p-3.5 border border-slate-100 rounded-xl">
                      <span className="text-[10px] text-slate-400 font-mono">RISK (%)</span>
                      <div className="text-lg font-mono font-bold text-slate-900 mt-1">{sizerRiskPercent}%</div>
                      <span className="text-[9px] text-slate-400 font-mono">Based on Tier</span>
                    </div>
                    <div className="bg-slate-50 p-3.5 border border-slate-100 rounded-xl">
                      <span className="text-[10px] text-slate-400 font-mono">RISK VALUE ($)</span>
                      <div className="text-lg font-mono font-bold text-slate-800 mt-1">${sizerResult.riskAmount.toLocaleString()}</div>
                      <span className="text-[9px] text-slate-400 font-mono">Absolute exposure</span>
                    </div>
                    <div className="bg-slate-50 p-3.5 border border-slate-100 rounded-xl">
                      <span className="text-[10px] text-slate-400 font-mono">LOT ALLOCATION</span>
                      <div className="text-lg font-mono font-bold text-slate-900 mt-1">
                        {sizerResult.positionSize}
                        <span className="text-xs text-slate-500 font-normal ml-1">
                          {sizerAssetType === "forex" ? "Lots" : "Units"}
                        </span>
                      </div>
                      <span className="text-[9px] text-slate-400 font-mono">Mechanical trade size</span>
                    </div>
                    <div className="bg-slate-50 p-3.5 border border-slate-100 rounded-xl">
                      <span className="text-[10px] text-slate-400 font-mono">STOP SPAN</span>
                      <div className="text-lg font-mono font-bold text-red-600 mt-1">
                        {sizerStopLossDist}
                        <span className="text-xs text-slate-500 font-normal ml-1">
                          {sizerAssetType === "forex" ? "Pips" : "Pts"}
                        </span>
                      </div>
                      <span className="text-[9px] text-slate-400 font-mono">1.5x ATR Volatility</span>
                    </div>
                  </div>

                  <hr className="border-slate-100" />

                  {/* Profit Target Roadmaps */}
                  <div className="space-y-4">
                    <h4 className="text-xs font-bold text-slate-800 font-display">6-Step Execution Protocol Milestones</h4>
                    
                    <div className="space-y-3">
                      {/* Entry & SL */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg">
                          <div className="text-[10px] text-slate-400 font-mono">ENTRY BUY LIMIT</div>
                          <div className="text-sm font-mono font-bold text-slate-850 mt-0.5">{sizerEntryPrice.toFixed(sizerAssetType === "forex" ? 5 : 2)}</div>
                          <span className="text-[9px] text-slate-400 leading-normal block mt-1">Enter Limit Order immediately on Closed Signal Candle open.</span>
                        </div>
                        <div className="p-3 bg-red-50 border border-red-100 rounded-lg">
                          <div className="text-[10px] text-red-600 font-mono">PROTECTION STOP LOSS</div>
                          <div className="text-sm font-mono font-bold text-red-600 mt-0.5">{stopPrice.toFixed(sizerAssetType === "forex" ? 5 : 2)}</div>
                          <span className="text-[9px] text-red-500/75 leading-normal block mt-1">Placed precisely at 1.5x of the 14-period ATR.</span>
                        </div>
                      </div>

                      {/* Milestones timeline visual */}
                      <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl space-y-4">
                        <span className="text-[9px] text-slate-400 font-mono uppercase tracking-widest font-bold">EXECUTION ROADMAP</span>
                        
                        <div className="space-y-3.5 text-xs">
                          {/* Target 1 */}
                          <div className="flex items-start justify-between border-b border-slate-150 pb-2.5">
                            <div className="space-y-0.5">
                              <span className="font-bold text-emerald-600 flex items-center gap-1">
                                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
                                Target 1 (1.5x Risk) • Protected
                              </span>
                              <p className="text-[10px] text-slate-500 leading-normal">
                                Rule: Move initial Stop Loss to Breakeven instantly. Trade is now secured at $0 loss potential.
                              </p>
                            </div>
                            <span className="font-mono font-bold text-slate-800 text-right shrink-0 ml-4">
                              {target1Price.toFixed(sizerAssetType === "forex" ? 5 : 2)}
                              <span className="block text-[9px] font-normal text-slate-400 mt-0.5">
                                +${(sizerResult.riskAmount * 1.5).toLocaleString()}
                              </span>
                            </span>
                          </div>

                          {/* Target 2 */}
                          <div className="flex items-start justify-between border-b border-slate-150 pb-2.5">
                            <div className="space-y-0.5">
                              <span className="font-bold text-emerald-600 flex items-center gap-1">
                                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
                                Target 2 (3.0x Risk) • Close 50% Partials
                              </span>
                              <p className="text-[10px] text-slate-500 leading-normal">
                                Rule: Close half of your position. Lock in profit. Trailing stop is activated on remainder.
                              </p>
                            </div>
                            <span className="font-mono font-bold text-slate-800 text-right shrink-0 ml-4">
                              {target2Price.toFixed(sizerAssetType === "forex" ? 5 : 2)}
                              <span className="block text-[9px] font-normal text-slate-400 mt-0.5">
                                +${(sizerResult.riskAmount * 3.0).toLocaleString()}
                              </span>
                            </span>
                          </div>

                          {/* Target 3 */}
                          <div className="flex items-start justify-between">
                            <div className="space-y-0.5">
                              <span className="font-bold text-emerald-700 flex items-center gap-1">
                                <span className="h-1.5 w-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
                                Target 3 (5.0x Risk) • Trailing Limit
                              </span>
                              <p className="text-[10px] text-slate-500 leading-normal">
                                Rule: Final expected milestone. Manage the remaining 50% with an ATR trailing stop.
                              </p>
                            </div>
                            <span className="font-mono font-bold text-slate-800 text-right shrink-0 ml-4">
                              {target3Price.toFixed(sizerAssetType === "forex" ? 5 : 2)}
                              <span className="block text-[9px] font-normal text-slate-400 mt-0.5">
                                +${(sizerResult.riskAmount * 5.0).toLocaleString()}
                              </span>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50/50 border border-blue-100 p-5 rounded-xl flex items-center justify-between shadow-sm">
                  <div className="flex items-center gap-3">
                    <Award className="h-5 w-5 text-blue-500 animate-pulse" />
                    <div>
                      <h4 className="text-xs font-bold text-slate-800 font-display">Test your discipline in the funded simulator</h4>
                      <p className="text-[10px] text-slate-500 mt-0.5">Simulate prop challenges, manage daily drawdown limits, and pass the evaluation.</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab("simulator")}
                    className="flex items-center gap-1 text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white px-3.5 py-2 rounded-lg shadow-sm transition-colors whitespace-nowrap"
                  >
                    Go to Simulator
                    <ArrowRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 4: CHALLENGE SIMULATOR */}
          {activeTab === "simulator" && (
            <motion.div
              key="simulator-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="space-y-6"
            >
              
              {/* Header Status Bar */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                
                {/* Account balance */}
                <div className="bg-white border border-slate-200 p-4 rounded-xl flex items-center justify-between shadow-sm">
                  <div className="space-y-0.5">
                    <span className="text-[10px] text-slate-400 font-mono">ACCOUNT EQUITY</span>
                    <div className="text-lg font-mono font-bold text-slate-900">${simState.balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                    <span className="text-[9px] text-slate-400 font-mono">Goal: $110,000 (+10%)</span>
                  </div>
                  <div className="p-2 bg-slate-50 border border-slate-200/60 rounded-lg">
                    <DollarSign className="h-5 w-5 text-slate-700" />
                  </div>
                </div>

                {/* Trailing Drawdown Limit Floor */}
                <div className="bg-white border border-slate-200 p-4 rounded-xl flex items-center justify-between shadow-sm">
                  <div className="space-y-0.5">
                    <span className="text-[10px] text-slate-400 font-mono">PEAK TRAILING DD</span>
                    <div className="text-lg font-mono font-bold text-red-600">
                      {simState.maxTrailingDrawdown.toFixed(2)}%
                    </div>
                    <span className="text-[9px] text-slate-400 font-mono">Limit: 8.00% Max</span>
                  </div>
                  <div className="p-2 bg-slate-50 border border-slate-200/60 rounded-lg">
                    <ShieldCheck className="h-5 w-5 text-red-500" />
                  </div>
                </div>

                {/* Daily Loss Tracker */}
                <div className="bg-white border border-slate-200 p-4 rounded-xl flex items-center justify-between shadow-sm">
                  <div className="space-y-0.5">
                    <span className="text-[10px] text-slate-400 font-mono">DAILY LOSS</span>
                    <div className="text-lg font-mono font-bold text-slate-700">
                      ${simState.dailyLossTotal.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </div>
                    <span className="text-[9px] text-slate-400 font-mono">Limit: $1,500 (1.5%)</span>
                  </div>
                  <div className="p-2 bg-slate-50 border border-slate-200/60 rounded-lg">
                    <Clock className="h-5 w-5 text-slate-500" />
                  </div>
                </div>

                {/* Challenge Status */}
                <div className="bg-white border border-slate-200 p-4 rounded-xl flex items-center justify-between shadow-sm">
                  <div className="space-y-0.5">
                    <span className="text-[10px] text-slate-400 font-mono">STATUS STATE</span>
                    <div className="text-sm font-bold font-display mt-0.5">
                      {simState.isPassed && <span className="text-emerald-600">PASSED • FUNDED</span>}
                      {simState.isFailed && <span className="text-red-500">FAILED • RESET</span>}
                      {!simState.isPassed && !simState.isFailed && <span className="text-slate-800">ACTIVE CHALLENGE</span>}
                    </div>
                    <span className="text-[9px] text-slate-400 font-mono">Trades taken: {simState.tradeHistory.length}</span>
                  </div>
                  <div className="p-2 bg-slate-50 border border-slate-200/60 rounded-lg">
                    {simState.isPassed ? (
                      <Award className="h-5 w-5 text-emerald-600 animate-bounce" />
                    ) : simState.isFailed ? (
                      <XCircle className="h-5 w-5 text-red-500" />
                    ) : (
                      <Activity className="h-5 w-5 text-slate-700 animate-pulse" />
                    )}
                  </div>
                </div>
              </div>

              {/* Simulation Game Panel */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                
                {/* Left: Setup generator */}
                <div className="lg:col-span-7 space-y-6">
                  
                  {simState.isPausedFor30m && (
                    <div className="bg-amber-50 border border-amber-200 p-5 rounded-xl space-y-3">
                      <div className="flex items-start gap-3">
                        <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                        <div className="space-y-1">
                          <h4 className="text-sm font-bold text-slate-850 font-display">Reset Rule Active (3 Consecutive Losses)</h4>
                          <p className="text-xs text-slate-600 leading-relaxed">
                            USME Risk Pillar Six: "After three consecutive losses, pause for 30 minutes. Step back, review your setups, and reset mentally before continuing."
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={resetConsecutiveLosses}
                        className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-3.5 py-1.5 rounded-lg flex items-center gap-1 transition-all shadow-sm"
                      >
                        <RotateCcw className="h-3.5 w-3.5" />
                        Complete mental reset (Unlock)
                      </button>
                    </div>
                  )}

                  {/* Generated Trade setup card */}
                  <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-5 relative shadow-sm">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                      <div>
                        <span className="text-[9px] text-slate-400 font-mono tracking-widest uppercase font-bold">PROP MARKET FEED GENERATOR</span>
                        <h3 className="text-sm font-bold text-slate-850 font-display mt-0.5">Active Setup Offer</h3>
                      </div>
                      <div className="flex items-center gap-2">
                        <label className="text-[10px] text-slate-400 font-mono uppercase whitespace-nowrap">Win Rate (%)</label>
                        <input
                          type="number"
                          value={simWinRate}
                          onChange={(e) => setSimWinRate(Math.min(100, Math.max(0, Number(e.target.value))))}
                          className="w-14 bg-slate-50 text-xs border border-slate-200 rounded p-1 text-center text-slate-700 font-mono focus:outline-none focus:ring-1 focus:ring-slate-900 focus:bg-white"
                          title="Tweak to simulate different execution skill levels"
                        />
                      </div>
                    </div>

                    {currentSetup ? (
                      <div className="space-y-4">
                        {/* Setup details */}
                        <div className="bg-slate-50 p-4 border border-slate-100 rounded-xl space-y-3">
                          <div className="flex items-center justify-between border-b border-slate-150 pb-2">
                            <span className="text-xs font-bold text-slate-800 font-mono">{currentSetup.asset}</span>
                            <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                              currentSetup.tier === "ELITE" 
                                ? "bg-slate-900 text-white" 
                                : currentSetup.tier === "PRIME" 
                                  ? "bg-slate-800 text-slate-100" 
                                  : "bg-slate-100 text-slate-600 border border-slate-200"
                            }`}>
                              {currentSetup.tier} SIGNAL ({currentSetup.calculatedScore}%)
                            </span>
                          </div>

                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs leading-normal">
                            <div>
                              <span className="text-slate-400 block text-[9px] font-mono uppercase">Session Time</span>
                              <span className={`font-semibold ${currentSetup.sessionTime === "off_hours" ? "text-red-600" : "text-slate-800"}`}>
                                {currentSetup.sessionTime === "london" ? "London" : currentSetup.sessionTime === "ny_open" ? "NY Open" : "Off-Hours"}
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-400 block text-[9px] font-mono uppercase">Biases alignment</span>
                              <span className={`font-semibold ${currentSetup.weeklyBias === currentSetup.dailyBias && currentSetup.weeklyBias !== "mixed" ? "text-emerald-600" : "text-red-600"}`}>
                                {currentSetup.weeklyBias.toUpperCase()} / {currentSetup.dailyBias.toUpperCase()}
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-400 block text-[9px] font-mono uppercase">Signal candle closed?</span>
                              <span className={`font-semibold ${currentSetup.closedCandle ? "text-emerald-600" : "text-red-600"}`}>
                                {currentSetup.closedCandle ? "Yes" : "No (Forms)"}
                              </span>
                            </div>
                          </div>

                          <p className="text-xs text-slate-600 italic pt-2 border-t border-slate-150/80">
                            "{currentSetup.description}"
                          </p>
                        </div>

                        {/* Gate checks summary */}
                        <div className="grid grid-cols-2 gap-2 text-center text-[11px] font-mono">
                          <div className={`p-1.5 border rounded-lg ${currentSetup.calculatedScore >= 80 ? "bg-emerald-50 border-emerald-200 text-emerald-600" : "bg-red-50 border-red-150/80 text-red-600"}`}>
                            SMS score {currentSetup.calculatedScore}% {currentSetup.calculatedScore >= 80 ? "(PASS)" : "(FAIL)"}
                          </div>
                          <div className={`p-1.5 border rounded-lg ${currentSetup.sessionTime !== "off_hours" ? "bg-emerald-50 border-emerald-200 text-emerald-600" : "bg-red-50 border-red-150/80 text-red-600"}`}>
                            Session: {currentSetup.sessionTime !== "off_hours" ? "Killzone PASS" : "Off-Hours REJECT"}
                          </div>
                        </div>

                        {/* Action buttons */}
                        <div className="flex gap-3 pt-2">
                          <button
                            onClick={handleSkipSetup}
                            className="flex-1 bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-slate-800 border border-slate-200 py-3 rounded-lg text-xs font-semibold transition-all"
                          >
                            Skip Setup (Saves Drawdown)
                          </button>
                          
                          <button
                            onClick={handleExecuteTrade}
                            disabled={simState.isPassed || simState.isFailed || simState.isPausedFor30m}
                            className="flex-1 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-100 disabled:text-slate-400 text-white font-semibold py-3 rounded-lg text-xs shadow-sm transition-all"
                          >
                            Execute Trade (USME Protocol)
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="py-12 text-center text-xs text-slate-400">
                        Generating active market feed...
                      </div>
                    )}

                    {/* Simulation complete state */}
                    {(simState.isPassed || simState.isFailed) && (
                      <div className="absolute inset-0 bg-white/95 rounded-xl flex flex-col items-center justify-center p-6 text-center space-y-4 border border-slate-200 z-10">
                        {simState.isPassed ? (
                          <>
                            <div className="inline-flex p-3 bg-emerald-50 text-emerald-600 border border-emerald-200 rounded-full animate-pulse">
                              <Award className="h-10 w-10" />
                            </div>
                            <div className="space-y-1">
                              <h4 className="text-base font-bold text-slate-900 font-display">🏆 Prop Evaluation Succeeded!</h4>
                              <p className="text-xs text-slate-500">You reached the 10% target while staying fully compliant with all risk models.</p>
                            </div>
                            <div className="flex gap-3">
                              <button
                                onClick={() => setShowCertificate(true)}
                                className="bg-emerald-600 text-white font-semibold text-xs px-4 py-2 rounded-lg hover:bg-emerald-700 transition shadow-sm"
                              >
                                View Certificate
                              </button>
                              <button
                                onClick={resetSimulator}
                                className="bg-slate-100 text-slate-700 border border-slate-200 font-semibold text-xs px-4 py-2 rounded-lg hover:bg-slate-250 transition"
                              >
                                Try Challenge Again
                              </button>
                            </div>
                          </>
                        ) : (
                          <>
                            <div className="inline-flex p-3 bg-red-50 text-red-600 border border-red-200 rounded-full">
                              <XCircle className="h-10 w-10" />
                            </div>
                            <div className="space-y-2 max-w-md">
                              <h4 className="text-sm font-bold text-slate-900 font-display">💥 Evaluation Failed</h4>
                              <p className="text-xs text-slate-600 leading-relaxed text-left bg-slate-50 p-3.5 border border-slate-200 rounded-lg">
                                {simState.failureReason}
                              </p>
                            </div>
                            <button
                              onClick={resetSimulator}
                              className="bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs px-4 py-2 rounded-lg shadow-sm transition"
                            >
                              Reset Challenge & Retry
                            </button>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Right: Simulation trade ledger */}
                <div className="lg:col-span-5 space-y-6">
                  <div className="bg-white border border-slate-200 p-6 rounded-xl space-y-4 flex flex-col h-[400px] shadow-sm">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                      <div>
                        <span className="text-[9px] text-slate-400 font-mono tracking-wider uppercase font-bold">LEDGER</span>
                        <h3 className="text-sm font-bold text-slate-800 font-display mt-0.5">Prop Account Statement</h3>
                      </div>
                      <button
                        onClick={resetSimulator}
                        className="text-[10px] font-mono text-slate-500 hover:text-slate-800 border border-slate-200 hover:bg-slate-50 px-2.5 py-1 rounded transition-colors"
                      >
                        Reset Ledger
                      </button>
                    </div>

                    {/* Trade history stack */}
                    <div className="flex-1 overflow-y-auto space-y-2">
                      {simState.tradeHistory.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-center p-4">
                          <Activity className="h-8 w-8 text-slate-300 animate-pulse" />
                          <p className="text-xs text-slate-400 mt-2 font-display">Ledger is empty. Execute setups to populate trade statements.</p>
                        </div>
                      ) : (
                        simState.tradeHistory.map((trade) => (
                          <div key={trade.id} className="p-3 bg-slate-50 border border-slate-100/70 rounded-lg flex items-center justify-between gap-3 text-xs leading-normal shadow-sm">
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-1.5">
                                <span className="font-mono text-[10px] text-slate-400">#{trade.tradeNumber}</span>
                                <span className="font-semibold text-slate-700">{trade.setupName}</span>
                              </div>
                              <p className="text-[10px] text-slate-400 line-clamp-1">{trade.notes}</p>
                            </div>
                            <div className="flex items-center gap-3 shrink-0">
                              <div className="text-right">
                                <span className={`font-mono font-bold ${trade.pnlAmount >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                                  {trade.pnlAmount >= 0 ? "+" : ""}${trade.pnlAmount.toLocaleString(undefined, { maximumFractionDigits: 1 })}
                                </span>
                                <span className={`block text-[9px] font-mono ${trade.pnlPercentage >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                                  {trade.pnlPercentage >= 0 ? "+" : ""}{trade.pnlPercentage.toFixed(3)}%
                                </span>
                              </div>
                              <button
                                onClick={() => handleImportSimToJournal(trade)}
                                className="p-1.5 bg-white border border-slate-200 text-slate-500 hover:text-slate-800 rounded-lg shadow-xs hover:border-slate-300 transition"
                                title="Log simulated trade to journal"
                              >
                                <BookMarked className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </div>
                        ))
                      )}
                    </div>

                    <div className="border-t border-slate-100 pt-3 text-xs flex justify-between font-mono text-slate-500">
                      <span>Total statement balance:</span>
                      <span className="font-bold text-slate-800">${simState.balance.toLocaleString(undefined, { maximumFractionDigits: 1 })}</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 5: DIGITAL TRADE JOURNAL */}
          {activeTab === "journal" && (
            <motion.div
              key="journal-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="space-y-8"
            >
              {/* Journal Metrics Header */}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm space-y-1">
                  <span className="text-[10px] text-slate-400 font-mono tracking-wider uppercase block font-semibold">Total Logged Trades</span>
                  <div className="text-2xl font-bold font-mono text-slate-800">{journalEntries.length}</div>
                  <span className="text-[10px] text-slate-400">Recorded executions</span>
                </div>
                
                <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm space-y-1">
                  <span className="text-[10px] text-slate-400 font-mono tracking-wider uppercase block font-semibold">Win Rate %</span>
                  <div className="text-2xl font-bold font-mono text-slate-800">
                    {journalEntries.length > 0 
                      ? `${((journalEntries.filter(t => t.isWin).length / journalEntries.length) * 100).toFixed(0)}%`
                      : "0%"
                    }
                  </div>
                  <span className="text-[10px] text-slate-400">
                    {journalEntries.filter(t => t.isWin).length} Wins / {journalEntries.filter(t => !t.isWin).length} Losses
                  </span>
                </div>

                <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm space-y-1 col-span-2 md:col-span-1">
                  <span className="text-[10px] text-slate-400 font-mono tracking-wider uppercase block font-semibold">Net P&L (Est.)</span>
                  <div className={`text-2xl font-bold font-mono ${
                    journalEntries.reduce((acc, t) => acc + t.pnlAmount, 0) >= 0 ? "text-emerald-600" : "text-red-600"
                  }`}>
                    {journalEntries.reduce((acc, t) => acc + t.pnlAmount, 0) >= 0 ? "+" : ""}$
                    {journalEntries.reduce((acc, t) => acc + t.pnlAmount, 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </div>
                  <span className="text-[10px] text-slate-400">
                    {journalEntries.reduce((acc, t) => acc + t.pnlPercentage, 0).toFixed(2)}% net account equity
                  </span>
                </div>

                <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm space-y-1">
                  <span className="text-[10px] text-slate-400 font-mono tracking-wider uppercase block font-semibold">Avg USME Confluence</span>
                  <div className="text-2xl font-bold font-mono text-slate-800">
                    {journalEntries.length > 0 
                      ? `${(journalEntries.reduce((acc, t) => acc + t.smartMoneyScore, 0) / journalEntries.length).toFixed(0)}%`
                      : "0%"
                    }
                  </div>
                  <span className="text-[10px] text-slate-400">Requires 80%+ threshold</span>
                </div>

                <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm space-y-1">
                  <span className="text-[10px] text-slate-400 font-mono tracking-wider uppercase block font-semibold">Masterplan Adherence</span>
                  <div className="text-2xl font-bold font-mono text-emerald-600">
                    {journalEntries.length > 0 
                      ? `${((journalEntries.filter(t => t.adheredToMasterplan === "fully").length / journalEntries.length) * 100).toFixed(0)}%`
                      : "0%"
                    }
                  </div>
                  <span className="text-[10px] text-slate-400">Full rule agreement rate</span>
                </div>
              </div>

              {/* Filtering & Action Bar */}
              <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex flex-1 flex-col md:flex-row items-stretch md:items-center gap-3">
                  {/* Search */}
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Search asset, direction, or notes..."
                      value={journalSearch}
                      onChange={(e) => setJournalSearch(e.target.value)}
                      className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-400 text-slate-700"
                    />
                  </div>

                  {/* Adherence Filter */}
                  <select
                    value={journalFilterAdherence}
                    onChange={(e) => setJournalFilterAdherence(e.target.value as any)}
                    className="bg-slate-50 border border-slate-200 px-3 py-2 text-xs rounded-lg text-slate-600 focus:outline-none focus:ring-1 focus:ring-slate-400"
                  >
                    <option value="all">All Adherence Levels</option>
                    <option value="fully">Fully Adhered (Strict)</option>
                    <option value="partially">Partially Adhered</option>
                    <option value="no">Violated (No Adherence)</option>
                  </select>

                  {/* Outcome Filter */}
                  <select
                    value={journalFilterOutcome}
                    onChange={(e) => setJournalFilterOutcome(e.target.value as any)}
                    className="bg-slate-50 border border-slate-200 px-3 py-2 text-xs rounded-lg text-slate-600 focus:outline-none focus:ring-1 focus:ring-slate-400"
                  >
                    <option value="all">All Outcomes</option>
                    <option value="win">Wins Only</option>
                    <option value="loss">Losses Only</option>
                  </select>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={openAddEntryForm}
                    className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-2 rounded-lg flex items-center gap-2 shadow-sm transition-all whitespace-nowrap"
                  >
                    <Plus className="h-4 w-4" />
                    Log Custom Trade
                  </button>
                </div>
              </div>

              {/* Form Modal / Overlay / Form section */}
              {isAddingEntry && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  className="bg-white border-2 border-slate-900 rounded-xl p-6 shadow-md space-y-6"
                >
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <h3 className="text-sm font-bold text-slate-800 font-display flex items-center gap-2">
                      <BookMarked className="h-4 w-4 text-slate-700" />
                      {editingEntryId ? "Edit Trade Journal Entry" : "Log New Trade Execution"}
                    </h3>
                    <button
                      type="button"
                      onClick={() => {
                        setIsAddingEntry(false);
                        setEditingEntryId(null);
                      }}
                      className="text-xs font-mono text-slate-400 hover:text-slate-600"
                    >
                      Cancel
                    </button>
                  </div>

                  <form onSubmit={handleSaveEntry} className="space-y-6">
                    {/* Step 1: Basic specifications */}
                    <div className="space-y-3">
                      <h4 className="text-[11px] font-mono font-bold text-slate-400 uppercase tracking-widest">1. Trade Setup Identification</h4>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div>
                          <label className="text-[10px] text-slate-500 font-mono uppercase block mb-1">Date</label>
                          <input
                            type="date"
                            value={formDate}
                            onChange={(e) => setFormDate(e.target.value)}
                            required
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-slate-400"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-slate-500 font-mono uppercase block mb-1">Asset Name</label>
                          <input
                            type="text"
                            placeholder="e.g. EURUSD, GBPUSD"
                            value={formAsset}
                            onChange={(e) => setFormAsset(e.target.value)}
                            required
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-slate-400 font-mono"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-slate-500 font-mono uppercase block mb-1">Direction</label>
                          <select
                            value={formDirection}
                            onChange={(e) => setFormDirection(e.target.value as any)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-slate-400 font-bold"
                          >
                            <option value="LONG" className="text-emerald-600 font-bold">LONG (BULLISH)</option>
                            <option value="SHORT" className="text-red-600 font-bold">SHORT (BEARISH)</option>
                          </select>
                        </div>

                        <div>
                          <label className="text-[10px] text-slate-500 font-mono uppercase block mb-1">USME Confluence Score (%)</label>
                          <input
                            type="number"
                            min="0"
                            max="100"
                            value={formScore}
                            onChange={(e) => setFormScore(parseInt(e.target.value) || 0)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-slate-400 font-mono"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Step 2: Levels */}
                    <div className="space-y-3 pt-3 border-t border-slate-100">
                      <h4 className="text-[11px] font-mono font-bold text-slate-400 uppercase tracking-widest">2. Price Execution Levels</h4>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div>
                          <label className="text-[10px] text-slate-500 font-mono uppercase block mb-1">Entry Price</label>
                          <input
                            type="number"
                            step="any"
                            placeholder="0.00000"
                            value={formEntryPrice}
                            onChange={(e) => setFormEntryPrice(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-slate-400 font-mono"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-slate-500 font-mono uppercase block mb-1">Exit Price</label>
                          <input
                            type="number"
                            step="any"
                            placeholder="0.00000"
                            value={formExitPrice}
                            onChange={(e) => setFormExitPrice(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-slate-400 font-mono"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-slate-500 font-mono uppercase block mb-1">Stop Loss</label>
                          <input
                            type="number"
                            step="any"
                            placeholder="0.00000"
                            value={formStopLoss}
                            onChange={(e) => setFormStopLoss(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-slate-400 font-mono"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-slate-500 font-mono uppercase block mb-1">Take Profit</label>
                          <input
                            type="number"
                            step="any"
                            placeholder="0.00000"
                            value={formTakeProfit}
                            onChange={(e) => setFormTakeProfit(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-slate-400 font-mono"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Step 3: Gateway Filters compliance */}
                    <div className="space-y-3 pt-3 border-t border-slate-100">
                      <h4 className="text-[11px] font-mono font-bold text-slate-400 uppercase tracking-widest">3. Mechanical Gateway Filter Results</h4>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <label className="flex items-center gap-3 p-2.5 bg-slate-50 border border-slate-200/60 rounded-lg cursor-pointer">
                          <input
                            type="checkbox"
                            checked={formKillzone}
                            onChange={(e) => setFormKillzone(e.target.checked)}
                            className="h-4 w-4 text-slate-950 focus:ring-slate-500 rounded border-slate-300"
                          />
                          <div>
                            <span className="text-xs font-bold text-slate-700 block">Killzone Confirmed</span>
                            <span className="text-[9px] text-slate-400">Trade within time volume</span>
                          </div>
                        </label>

                        <label className="flex items-center gap-3 p-2.5 bg-slate-50 border border-slate-200/60 rounded-lg cursor-pointer">
                          <input
                            type="checkbox"
                            checked={formHtfBias}
                            onChange={(e) => setFormHtfBias(e.target.checked)}
                            className="h-4 w-4 text-slate-950 focus:ring-slate-500 rounded border-slate-300"
                          />
                          <div>
                            <span className="text-xs font-bold text-slate-700 block">HTF Bias Agreement</span>
                            <span className="text-[9px] text-slate-400">Weekly & Daily aligned</span>
                          </div>
                        </label>

                        <div className="flex items-center gap-3 p-2.5 bg-slate-50 border border-slate-200/60 rounded-lg">
                          <Check className="h-4 w-4 text-slate-700" />
                          <div>
                            <span className="text-xs font-bold text-slate-700 block">SMS threshold 80%?</span>
                            <span className="text-[9px] text-slate-400">{formScore >= 80 ? "PASSED" : "FAILED / STANDARDISED"}</span>
                          </div>
                        </div>

                        <label className="flex items-center gap-3 p-2.5 bg-slate-50 border border-slate-200/60 rounded-lg cursor-pointer">
                          <input
                            type="checkbox"
                            checked={formClosedCandle}
                            onChange={(e) => setFormClosedCandle(e.target.checked)}
                            className="h-4 w-4 text-slate-950 focus:ring-slate-500 rounded border-slate-300"
                          />
                          <div>
                            <span className="text-xs font-bold text-slate-700 block">Closed Candle Rule</span>
                            <span className="text-[9px] text-slate-400">Signals only on close</span>
                          </div>
                        </label>
                      </div>
                    </div>

                    {/* Step 4: Execution protocols */}
                    <div className="space-y-3 pt-3 border-t border-slate-100">
                      <h4 className="text-[11px] font-mono font-bold text-slate-400 uppercase tracking-widest">4. Execution Protocols Followed</h4>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <label className="flex items-center gap-3 p-2.5 bg-slate-50 border border-slate-200/60 rounded-lg cursor-pointer">
                          <input
                            type="checkbox"
                            checked={formProtoLimitEntry}
                            onChange={(e) => setFormProtoLimitEntry(e.target.checked)}
                            className="h-4 w-4 text-slate-950 focus:ring-slate-500 rounded border-slate-300"
                          />
                          <div>
                            <span className="text-xs font-bold text-slate-700 block">Protocol 1: Limit entry FVG/OB</span>
                            <span className="text-[9px] text-slate-400">Resting limit, no chasing market</span>
                          </div>
                        </label>

                        <label className="flex items-center gap-3 p-2.5 bg-slate-50 border border-slate-200/60 rounded-lg cursor-pointer">
                          <input
                            type="checkbox"
                            checked={formProtoAtrStopLoss}
                            onChange={(e) => setFormProtoAtrStopLoss(e.target.checked)}
                            className="h-4 w-4 text-slate-950 focus:ring-slate-500 rounded border-slate-300"
                          />
                          <div>
                            <span className="text-xs font-bold text-slate-700 block">Protocol 2: 1.5x ATR Stop Loss</span>
                            <span className="text-[9px] text-slate-400">Dynamic buffer against noise</span>
                          </div>
                        </label>

                        <label className="flex items-center gap-3 p-2.5 bg-slate-50 border border-slate-200/60 rounded-lg cursor-pointer">
                          <input
                            type="checkbox"
                            checked={formProtoSotdRisk}
                            onChange={(e) => setFormProtoSotdRisk(e.target.checked)}
                            className="h-4 w-4 text-slate-950 focus:ring-slate-500 rounded border-slate-300"
                          />
                          <div>
                            <span className="text-xs font-bold text-slate-700 block">Protocol 3: SOTD Position Sizing</span>
                            <span className="text-[9px] text-slate-400">Strictly 0.2%, 0.35%, or 0.5% risk</span>
                          </div>
                        </label>

                        <label className="flex items-center gap-3 p-2.5 bg-slate-50 border border-slate-200/60 rounded-lg cursor-pointer">
                          <input
                            type="checkbox"
                            checked={formProtoProtectedTarget}
                            onChange={(e) => setFormProtoProtectedTarget(e.target.checked)}
                            className="h-4 w-4 text-slate-950 focus:ring-slate-500 rounded border-slate-300"
                          />
                          <div>
                            <span className="text-xs font-bold text-slate-700 block">Protocol 4: Breakeven at 1.5R</span>
                            <span className="text-[9px] text-slate-400">Move SL once price displaces 1.5R</span>
                          </div>
                        </label>

                        <label className="flex items-center gap-3 p-2.5 bg-slate-50 border border-slate-200/60 rounded-lg cursor-pointer">
                          <input
                            type="checkbox"
                            checked={formProtoTakePartials}
                            onChange={(e) => setFormProtoTakePartials(e.target.checked)}
                            className="h-4 w-4 text-slate-950 focus:ring-slate-500 rounded border-slate-300"
                          />
                          <div>
                            <span className="text-xs font-bold text-slate-700 block">Protocol 5: 50% Partials at 3.0R</span>
                            <span className="text-[9px] text-slate-400">Bank 50% position once Target 3 is hit</span>
                          </div>
                        </label>

                        <label className="flex items-center gap-3 p-2.5 bg-slate-50 border border-slate-200/60 rounded-lg cursor-pointer">
                          <input
                            type="checkbox"
                            checked={formProtoTrailingStop}
                            onChange={(e) => setFormProtoTrailingStop(e.target.checked)}
                            className="h-4 w-4 text-slate-950 focus:ring-slate-500 rounded border-slate-300"
                          />
                          <div>
                            <span className="text-xs font-bold text-slate-700 block">Protocol 6: Trail with ATR stop</span>
                            <span className="text-[9px] text-slate-400">Secure remainder with ATR trailing stop</span>
                          </div>
                        </label>
                      </div>
                    </div>

                    {/* Step 5: Profit override and masterplan adherence */}
                    <div className="space-y-3 pt-3 border-t border-slate-100">
                      <h4 className="text-[11px] font-mono font-bold text-slate-400 uppercase tracking-widest">5. Financial Outcome & Compliance</h4>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <label className="flex flex-col p-3 bg-slate-50 border border-slate-200/60 rounded-lg cursor-pointer col-span-1">
                          <div className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              checked={formAutoCalculatePnl}
                              onChange={(e) => setFormAutoCalculatePnl(e.target.checked)}
                              className="h-4 w-4 text-slate-950 focus:ring-slate-500 rounded border-slate-300"
                            />
                            <span className="text-xs font-bold text-slate-700">Auto Calculate PnL</span>
                          </div>
                          <span className="text-[9px] text-slate-400 mt-1">Computes PnL based on Entry & Exit prices</span>
                        </label>

                        {!formAutoCalculatePnl && (
                          <>
                            <div>
                              <label className="text-[10px] text-slate-500 font-mono uppercase block mb-1">PnL Amount (USD)</label>
                              <input
                                type="number"
                                placeholder="e.g. 1500 or -350"
                                value={formCustomPnlAmount}
                                onChange={(e) => setFormCustomPnlAmount(e.target.value)}
                                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-slate-400 font-mono font-bold"
                              />
                            </div>

                            <div>
                              <label className="text-[10px] text-slate-500 font-mono uppercase block mb-1">PnL Percentage (%)</label>
                              <input
                                type="number"
                                step="any"
                                placeholder="e.g. 1.5 or -0.35"
                                value={formCustomPnlPercentage}
                                onChange={(e) => setFormCustomPnlPercentage(e.target.value)}
                                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-slate-400 font-mono font-bold"
                              />
                            </div>
                          </>
                        )}

                        <div className={formAutoCalculatePnl ? "col-span-2" : "col-span-1"}>
                          <label className="text-[10px] text-slate-500 font-mono uppercase block mb-1">Overall Masterplan Adherence</label>
                          <select
                            value={formAdherence}
                            onChange={(e) => setFormAdherence(e.target.value as any)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-slate-400 font-bold"
                          >
                            <option value="fully" className="text-emerald-600 font-bold">Fully Adhered (Strictly compliant)</option>
                            <option value="partially" className="text-amber-600 font-bold">Partially Adhered (Minor protocol deviation)</option>
                            <option value="no" className="text-red-600 font-bold">Violated (Forced trade, off-hours, or over-risked)</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* Step 6: Text fields */}
                    <div className="space-y-4 pt-3 border-t border-slate-100">
                      <div>
                        <label className="text-[10px] text-slate-500 font-mono uppercase block mb-1">Trade Notes & Context (Pre-trade / entry thesis)</label>
                        <textarea
                          rows={3}
                          placeholder="Describe the setup, institutional footprint, swept liquidity, premium/discount array, and how you entered."
                          value={formNotes}
                          onChange={(e) => setFormNotes(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-slate-400 text-slate-700 font-sans"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] text-slate-500 font-mono uppercase block mb-1">Post-Trade Analysis & Areas for Improvement</label>
                        <textarea
                          rows={3}
                          placeholder="How did you handle management? Did you move SL to BE on time? Any emotional impulses or lessons learned?"
                          value={formPostAnalysis}
                          onChange={(e) => setFormPostAnalysis(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-slate-400 text-slate-700 font-sans"
                        />
                      </div>
                    </div>

                    {/* Submit actions */}
                    <div className="flex gap-3 pt-4 border-t border-slate-100 justify-end">
                      <button
                        type="button"
                        onClick={() => {
                          setIsAddingEntry(false);
                          setEditingEntryId(null);
                        }}
                        className="bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 font-semibold text-xs px-5 py-2.5 rounded-lg transition"
                      >
                        Cancel
                      </button>
                      
                      <button
                        type="submit"
                        className="bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs px-5 py-2.5 rounded-lg shadow-sm flex items-center gap-2 transition"
                      >
                        <Save className="h-4 w-4" />
                        Save Journal Entry
                      </button>
                    </div>
                  </form>
                </motion.div>
              )}

              {/* Journal Stack */}
              <div className="space-y-4">
                {/* Filter entries */}
                {(() => {
                  const filtered = journalEntries.filter(entry => {
                    const matchesSearch = 
                      entry.asset.toUpperCase().includes(journalSearch.toUpperCase()) ||
                      entry.notes.toUpperCase().includes(journalSearch.toUpperCase()) ||
                      entry.postTradeAnalysis.toUpperCase().includes(journalSearch.toUpperCase()) ||
                      entry.direction.toUpperCase().includes(journalSearch.toUpperCase());

                    const matchesAdherence = journalFilterAdherence === "all" || entry.adheredToMasterplan === journalFilterAdherence;
                    const matchesOutcome = journalFilterOutcome === "all" || (journalFilterOutcome === "win" ? entry.isWin : !entry.isWin);

                    return matchesSearch && matchesAdherence && matchesOutcome;
                  });

                  if (filtered.length === 0) {
                    return (
                      <div className="bg-white border border-slate-200 rounded-xl p-12 text-center space-y-3 shadow-sm">
                        <BookMarked className="h-8 w-8 text-slate-300 mx-auto animate-pulse" />
                        <h4 className="font-bold text-sm text-slate-800">No Journal Entries Found</h4>
                        <p className="text-xs text-slate-400 max-w-sm mx-auto leading-normal">
                          No trades match your current filters. Clear the search query or log a new trade execution.
                        </p>
                      </div>
                    );
                  }

                  return filtered.map((entry) => (
                    <motion.div
                      key={entry.id}
                      className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-200 border-l-4"
                      style={{
                        borderLeftColor: entry.isWin ? "#10b981" : "#ef4444"
                      }}
                    >
                      {/* Top Summary Bar */}
                      <div className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 font-sans">
                        <div className="space-y-1.5 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-[10px] text-slate-400 font-mono font-bold uppercase block bg-slate-100 px-2 py-0.5 rounded-md">
                              {entry.date}
                            </span>
                            
                            <span className="text-sm font-bold text-slate-800 font-display">
                              {entry.asset}
                            </span>

                            <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                              entry.direction === "LONG" 
                                ? "bg-emerald-50 text-emerald-600 border border-emerald-100" 
                                : "bg-red-50 text-red-600 border border-red-100"
                            }`}>
                              {entry.direction}
                            </span>

                            <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
                              entry.adheredToMasterplan === "fully" 
                                ? "bg-emerald-100 text-emerald-800 border border-emerald-200" 
                                : entry.adheredToMasterplan === "partially"
                                  ? "bg-amber-50 text-amber-700 border border-amber-200"
                                  : "bg-red-50 text-red-700 border border-red-200"
                            }`}>
                              {entry.adheredToMasterplan === "fully" ? "🛡️ Fully Compliant" : entry.adheredToMasterplan === "partially" ? "⚠️ Partial Adherence" : "💥 VIOLATION"}
                            </span>

                            <span className="text-[10px] font-mono text-slate-400">
                              SMS: {entry.smartMoneyScore}%
                            </span>
                          </div>

                          <p className="text-xs text-slate-600 line-clamp-2 italic">
                            "{entry.notes}"
                          </p>
                        </div>

                        {/* financial results and controls */}
                        <div className="flex items-center gap-6 justify-between md:justify-end">
                          <div className="text-left md:text-right space-y-0.5">
                            <span className="text-[9px] text-slate-400 block font-mono">FINANCIAL RESULT</span>
                            <div className="flex items-baseline gap-1.5 justify-start md:justify-end">
                              <span className={`text-sm font-bold font-mono ${entry.isWin ? "text-emerald-600" : "text-red-600"}`}>
                                {entry.pnlAmount >= 0 ? "+" : ""}${entry.pnlAmount.toLocaleString(undefined, { maximumFractionDigits: 1 })}
                              </span>
                              <span className={`text-[10px] font-mono ${entry.isWin ? "text-emerald-600" : "text-red-500"}`}>
                                ({entry.pnlPercentage >= 0 ? "+" : ""}{entry.pnlPercentage.toFixed(2)}%)
                              </span>
                            </div>
                          </div>

                          <div className="flex gap-2">
                            <button
                              onClick={() => openEditEntryForm(entry)}
                              className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-slate-700 rounded-lg transition"
                              title="Edit Entry"
                            >
                              <Edit3 className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteEntry(entry.id)}
                              className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-red-600 rounded-lg transition"
                              title="Delete Entry"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Detailed accordions/sub-grid */}
                      <div className="bg-slate-50/70 border-t border-slate-100 p-5 grid grid-cols-1 md:grid-cols-12 gap-6 text-xs leading-relaxed">
                        
                        {/* Mechanics column */}
                        <div className="md:col-span-4 space-y-3.5">
                          <h5 className="font-mono text-[10px] text-slate-400 uppercase tracking-widest font-bold">1. SETUP GATEWAYS</h5>
                          <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                            <div className={`p-2 border rounded-lg ${entry.killzone ? "bg-emerald-50/50 border-emerald-100 text-emerald-800" : "bg-red-50/30 border-red-100/70 text-red-800"}`}>
                              Killzone: {entry.killzone ? "PASS" : "REJECT"}
                            </div>
                            <div className={`p-2 border rounded-lg ${entry.htfBias ? "bg-emerald-50/50 border-emerald-100 text-emerald-800" : "bg-red-50/30 border-red-100/70 text-red-800"}`}>
                              HTF Bias: {entry.htfBias ? "PASS" : "CONFLICT"}
                            </div>
                            <div className={`p-2 border rounded-lg ${entry.smartMoneyScore >= 80 ? "bg-emerald-50/50 border-emerald-100 text-emerald-800" : "bg-red-50/30 border-red-100/70 text-red-800"}`}>
                              Score: {entry.smartMoneyScore}%
                            </div>
                            <div className={`p-2 border rounded-lg ${entry.closedCandle ? "bg-emerald-50/50 border-emerald-100 text-emerald-800" : "bg-red-50/30 border-red-100/70 text-red-800"}`}>
                              Signal Closed: {entry.closedCandle ? "YES" : "NO"}
                            </div>
                          </div>

                          <h5 className="font-mono text-[10px] text-slate-400 uppercase tracking-widest font-bold pt-1">2. PRICES</h5>
                          <div className="grid grid-cols-4 gap-2 text-center text-[10px] font-mono bg-white border border-slate-200/60 p-2 rounded-lg">
                            <div>
                              <span className="text-slate-400 block text-[8px]">ENTRY</span>
                              <span className="font-bold text-slate-700">{entry.entryPrice || "-"}</span>
                            </div>
                            <div>
                              <span className="text-slate-400 block text-[8px]">EXIT</span>
                              <span className="font-bold text-slate-700">{entry.exitPrice || "-"}</span>
                            </div>
                            <div>
                              <span className="text-slate-400 block text-[8px]">STOP</span>
                              <span className="font-bold text-red-500">{entry.stopLoss || "-"}</span>
                            </div>
                            <div>
                              <span className="text-slate-400 block text-[8px]">TARGET</span>
                              <span className="font-bold text-emerald-600">{entry.takeProfit || "-"}</span>
                            </div>
                          </div>
                        </div>

                        {/* Protocols checklist */}
                        <div className="md:col-span-4 space-y-3.5">
                          <h5 className="font-mono text-[10px] text-slate-400 uppercase tracking-widest font-bold">3. PROTOCOLS APPLIED</h5>
                          
                          <div className="space-y-1.5 font-mono text-[10px]">
                            <div className="flex items-center justify-between">
                              <span className="text-slate-500">P1: Limit inside FVG/OB</span>
                              <span className={entry.protocols.limitEntry ? "text-emerald-600 font-bold" : "text-red-500"}>
                                {entry.protocols.limitEntry ? "COMPLIANT" : "VIOLATED"}
                              </span>
                            </div>

                            <div className="flex items-center justify-between">
                              <span className="text-slate-500">P2: Stop loss at 1.5x ATR</span>
                              <span className={entry.protocols.atrStopLoss ? "text-emerald-600 font-bold" : "text-red-500"}>
                                {entry.protocols.atrStopLoss ? "COMPLIANT" : "VIOLATED"}
                              </span>
                            </div>

                            <div className="flex items-center justify-between">
                              <span className="text-slate-500">P3: SOTD Position Sizing</span>
                              <span className={entry.protocols.sotdRisk ? "text-emerald-600 font-bold" : "text-red-500"}>
                                {entry.protocols.sotdRisk ? "COMPLIANT" : "VIOLATED"}
                              </span>
                            </div>

                            <div className="flex items-center justify-between">
                              <span className="text-slate-500">P4: SL to Breakeven at 1.5R</span>
                              <span className={entry.protocols.protectedTarget ? "text-emerald-600 font-bold" : "text-slate-400"}>
                                {entry.protocols.protectedTarget ? "COMPLIANT" : "N/A / SKIPPED"}
                              </span>
                            </div>

                            <div className="flex items-center justify-between">
                              <span className="text-slate-500">P5: Close 50% Partials at 3R</span>
                              <span className={entry.protocols.takePartials ? "text-emerald-600 font-bold" : "text-slate-400"}>
                                {entry.protocols.takePartials ? "COMPLIANT" : "N/A / SKIPPED"}
                              </span>
                            </div>

                            <div className="flex items-center justify-between">
                              <span className="text-slate-500">P6: Trail remainder with ATR</span>
                              <span className={entry.protocols.trailingStop ? "text-emerald-600 font-bold" : "text-slate-400"}>
                                {entry.protocols.trailingStop ? "COMPLIANT" : "N/A / SKIPPED"}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Post analysis notes */}
                        <div className="md:col-span-4 space-y-3 bg-white p-4 rounded-xl border border-slate-200/60 shadow-inner">
                          <div>
                            <span className="font-mono text-[9px] text-slate-400 font-bold uppercase block">POST-TRADE ANALYSIS & LESSONS</span>
                            <p className="text-slate-600 text-xs mt-1 font-sans leading-relaxed whitespace-pre-line">
                              {entry.postTradeAnalysis || "No post-trade analysis provided yet. Select 'Edit' to record performance evaluations."}
                            </p>
                          </div>
                        </div>

                      </div>
                    </motion.div>
                  ));
                })()}
              </div>

            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* FOOTER */}
      <footer className="border-t border-slate-200 bg-slate-50 mt-16 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-2">
          <p className="text-xs text-slate-400 font-display">SniperTrader USME ICT Foundation Masterplan Workspace • Mechanical funded account strategy</p>
          <p className="text-[10px] text-slate-500 max-w-xl mx-auto font-sans leading-normal">
            Disclaimer: Trading financial instruments involves significant risk of loss. This workspace is strictly for educational simulation and prop calibration purposes. Past mechanical performance does not guarantee future live evaluation success.
          </p>
        </div>
      </footer>

      {/* CERTIFICATE MODAL */}
      <AnimatePresence>
        {showCertificate && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white border border-slate-200 max-w-2xl w-full p-8 rounded-2xl shadow-xl relative overflow-hidden text-center space-y-6"
            >
              {/* Background watermark decorations */}
              <div className="absolute inset-0 bg-gradient-to-b from-slate-50 to-transparent opacity-50 pointer-events-none"></div>
              
              <div className="inline-flex p-3.5 bg-emerald-50 text-emerald-600 border border-emerald-200 rounded-full animate-pulse">
                <Award className="h-12 w-12" />
              </div>

              <div className="space-y-2">
                <span className="text-[10px] font-mono text-emerald-600 uppercase tracking-widest block font-bold">SNIPERTRADER ACADEMY CERTIFIED</span>
                <h2 className="text-2xl font-bold font-display text-slate-900">USME MASTERPLAN EVALUATION SUCCESS</h2>
                <div className="h-0.5 w-16 bg-slate-200 mx-auto my-3"></div>
              </div>

              <p className="text-sm text-slate-600 leading-relaxed max-w-lg mx-auto">
                This certifies that the candidate has successfully completed the simulated <strong>United Smart Money Engine</strong> prop firm funded challenge, executing trade confluences strictly above 80% with ATR volatility buffers, while demonstrating immaculate adherence to the 1.5% daily, 3% weekly, and 8% peak trailing drawdown caps.
              </p>

              <div className="grid grid-cols-3 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200/60 max-w-md mx-auto text-center font-mono">
                <div>
                  <span className="text-[9px] text-slate-400">FINAL EQUITY</span>
                  <div className="text-xs font-bold text-slate-800 mt-1">${simState.balance.toLocaleString(undefined, { maximumFractionDigits: 0 })}</div>
                </div>
                <div>
                  <span className="text-[9px] text-slate-400">COMPLIANCE</span>
                  <div className="text-xs font-bold text-emerald-600 mt-1">100%</div>
                </div>
                <div>
                  <span className="text-[9px] text-slate-400">TRADES TAKEN</span>
                  <div className="text-xs font-bold text-slate-800 mt-1">{simState.tradeHistory.length}</div>
                </div>
              </div>

              <div className="pt-4 flex justify-center gap-3">
                <button
                  onClick={() => setShowCertificate(false)}
                  className="bg-slate-100 text-slate-700 border border-slate-200 px-5 py-2.5 rounded-lg text-xs font-bold hover:bg-slate-200 transition"
                >
                  Close Document
                </button>
                <button
                  onClick={resetSimulator}
                  className="bg-slate-900 hover:bg-slate-800 text-white px-5 py-2.5 rounded-lg text-xs font-bold shadow-md transition"
                >
                  Reset Challenge
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
