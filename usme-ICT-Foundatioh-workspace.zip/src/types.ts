export interface ConfluenceInputs {
  sessionTime: "london" | "ny_open" | "off_hours";
  weeklyBias: "bullish" | "bearish" | "mixed";
  dailyBias: "bullish" | "bearish" | "mixed";
  fvgObDetails: string;
  chochBosDetails: string;
  smtDetails: string;
  volumeDetails: string;
  closedCandle: boolean;
  userNotes: string;
}

export interface FactorScore {
  name: string;
  score: number; // out of 20
  details: string;
}

export interface GeminiAnalysisResponse {
  analysis: string;
  filterKillzone: {
    pass: boolean;
    details: string;
  };
  filterHTFBias: {
    pass: boolean;
    details: string;
    direction: "LONG ONLY" | "SHORT ONLY" | "NO TRADE";
  };
  filterSmartMoneyScore: {
    score: number;
    tier: "ELITE" | "PRIME" | "STANDARD";
    pass: boolean;
    factors: FactorScore[];
  };
  filterClosedCandle: {
    pass: boolean;
    details: string;
  };
  overallPass: boolean;
  executionPlan: {
    riskPercentage: number;
    entryAdvice: string;
    stopLossAdvice: string;
    targetsAdvice: string;
  };
  propChallengeContext: string;
}

export interface TradeSimulation {
  id: string;
  tradeNumber: number;
  setupName: string;
  tier: "ELITE" | "PRIME" | "STANDARD";
  riskPercentage: number;
  direction: "LONG" | "SHORT";
  outcome: "WIN_T1" | "WIN_T2" | "WIN_T3" | "LOSS";
  pnlAmount: number;
  pnlPercentage: number;
  endingBalance: number;
  peakEquity: number;
  trailingDrawdown: number; // current drawdown from peak equity
  notes: string;
}

export interface SimulatorState {
  accountSize: number;
  balance: number;
  peakEquity: number;
  maxTrailingDrawdown: number; // peak trailing drawdown reached
  consecutiveLosses: number;
  dailyLossTotal: number;
  weeklyLossTotal: number;
  tradeHistory: TradeSimulation[];
  isPassed: boolean;
  isFailed: boolean;
  failureReason: string;
  isPausedFor30m: boolean; // 30-min pause after 3 losses
}

export interface JournalEntry {
  id: string;
  date: string;
  asset: string;
  direction: "LONG" | "SHORT";
  entryPrice: number;
  exitPrice: number;
  stopLoss: number;
  takeProfit: number;
  // Trade setup filters
  killzone: boolean;         // Killzone filter passed
  htfBias: boolean;          // HTF Bias filter passed
  smartMoneyScore: number;   // out of 100
  closedCandle: boolean;     // Closed Candle Rule passed
  // Execution Protocols followed
  protocols: {
    limitEntry: boolean;     // Protocol 1: Limit entry inside FVG/OB
    atrStopLoss: boolean;    // Protocol 2: Stop loss at 1.5x ATR
    sotdRisk: boolean;       // Protocol 3: Position size according to SOTD Tier
    protectedTarget: boolean;// Protocol 4: Move SL to Breakeven at 1.5R
    takePartials: boolean;   // Protocol 5: Close 50% partials at 3.0R
    trailingStop: boolean;   // Protocol 6: Tail with ATR trailing stop
  };
  adheredToMasterplan: "fully" | "partially" | "no";
  notes: string;
  postTradeAnalysis: string;
  pnlAmount: number;         // PnL in USD (input or auto-calculated)
  pnlPercentage: number;     // PnL in percentage (input or auto-calculated)
  isWin: boolean;            // Win/Loss flag
}

